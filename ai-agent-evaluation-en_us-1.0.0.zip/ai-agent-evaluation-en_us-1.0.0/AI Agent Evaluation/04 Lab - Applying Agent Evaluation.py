# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC # Lab - Applying Agent Evaluation
# MAGIC
# MAGIC ## Overview
# MAGIC
# MAGIC This lab provides hands-on experience with MLflow's evaluation framework for generative AI agents. You will work with the NYC Taxi dataset to build evaluation workflows using both built-in judges (correctness, safety) and custom guideline judges.
# MAGIC
# MAGIC In this lab, you will create evaluation datasets, configure multiple types of judges, and analyze evaluation results to understand agent performance. The lab emphasizes practical implementation of automated evaluation workflows that can be applied to real-world AI applications.
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lab, you will be able to:
# MAGIC
# MAGIC - **Configure and execute** MLflow's built-in judges for correctness and safety assessment
# MAGIC - **Implement guideline judges** for custom business rule evaluation using natural language criteria
# MAGIC - **Create evaluation datasets** with proper structure for different judge types
# MAGIC - **Analyze evaluation results** using MLflow's tracing capabilities and result dataframes
# MAGIC - **Apply best practices** for separating evaluation models and managing configuration files
# MAGIC
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Prerequisites</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;"> This demo uses the agent created in <strong>01 - Agent Setup</strong>. Please ensure you have completed that notebook before proceeding.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Note</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">That you might need to rerun the cells in the notebook if you receive an <strong>ValueError</strong> or <strong>MLflowException</strong> error regarding a datatype that was generated as a part of the agent's trace.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. Environment Setup and Prerequisites
# MAGIC
# MAGIC This section covers the essential setup steps required before working with agent evaluation. We'll establish compute requirements, install dependencies, configure the environment, and load the NYC Taxi agent for evaluation.
# MAGIC
# MAGIC **WARNING:** Some of the TODOs down below rely on you config files stored in `./artifacts` - specifically those with `nyc` in the file names. Open those files and view the contents to help fill out some of the configuration information in this section.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A1. Compute Requirements
# MAGIC
# MAGIC This course has been configured to run on Serverless compute. While classic compute may also work, testing has been performed on serverless.
# MAGIC
# MAGIC **This demo was tested using version 4 of Serverless compute.** To ensure that you are using the correct version of Serverless, please [see this documentation on viewing and changing your notebook's Serverless version](https://docs.databricks.com/aws/en/compute/serverless/dependencies).
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required - Select Serverless Compute</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">You must attach this notebook to a Serverless compute resource before proceeding.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### A2. Install Dependencies
# MAGIC
# MAGIC As part of the workspace setup, several Python libraries will need to be installed by running the following setup script. This includes MLflow with Databricks integration and other required packages for evaluation.
# MAGIC
# MAGIC **MLflow Version Requirements:** This lab requires MLflow version 3.4.0 or higher for full evaluation functionality.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-4

# COMMAND ----------

# MAGIC %md
# MAGIC ### A3. Configure Environment Variables
# MAGIC
# MAGIC Set up the demo environment to get catalog, schema, and agent configuration. This will establish the Unity Catalog namespace and prepare the NYC Taxi agent for evaluation.

# COMMAND ----------

demo_setup = DemoSetup()

# Run the build-pipeline
demo_setup.run()

# Get the catalog, schema, and agent string values
catalog_name, schema_name, agent_name, experiment_name = demo_setup.get_env_vars()

# COMMAND ----------

# MAGIC %md
# MAGIC ### A4. Load and Configure the Agent
# MAGIC
# MAGIC Load the pre-trained NYC Taxi agent from Unity Catalog and configure MLflow tracking. This agent has two key functions:
# MAGIC
# MAGIC | Function | Description |
# MAGIC |----------|-------------|
# MAGIC | `trip_info(pickup_zip, dropoff_zip)` | Retrieves trip statistics (count, avg/min/max/median fare, distance) for specific pickup and dropoff zip codes |
# MAGIC | `calc_fare_est(trip_distance, base_fare)` | Calculates estimated fare based on trip distance and base fare amount |
# MAGIC
# MAGIC **Loading Models with MLflow:** We use `mlflow.pyfunc.load_model()` to load the agent from Unity Catalog. The model is referenced using its fully qualified name and alias (e.g., `models:/catalog.schema.model_name@champion`).

# COMMAND ----------

## Set up MLflow tracking and load the agent
import mlflow

## Enable MLflow's autologging for tracing
<FILL_IN>

## Set up MLflow tracking to Databricks
mlflow.set_tracking_uri(<FILL_IN>)

## Get username and set experiment name
username = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
EXPERIMENT_NAME = f"/Users/{username}/{experiment_name}"
mlflow.set_experiment(<FILL_IN>)

## Set the registry to Unity Catalog
mlflow.set_registry_uri(<FILL_IN>)

## Load the model using the UC path and alias
alias = "champion"
UC_MODEL_NAME = f"{catalog_name}.{schema_name}.{agent_name}"

## Load by alias
agent = mlflow.pyfunc.load_model(<FILL_IN>)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC <code>
# MAGIC import mlflow
# MAGIC
# MAGIC # Enable MLflow's autologging for tracing
# MAGIC mlflow.openai.autolog()
# MAGIC
# MAGIC # Set up MLflow tracking to Databricks
# MAGIC mlflow.set_tracking_uri("databricks")
# MAGIC
# MAGIC # Get username and set experiment name
# MAGIC username = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()
# MAGIC EXPERIMENT_NAME = f"/Users/{username}/{experiment_name}"
# MAGIC mlflow.set_experiment(EXPERIMENT_NAME)
# MAGIC
# MAGIC # Set the registry to Unity Catalog
# MAGIC mlflow.set_registry_uri("databricks-uc")
# MAGIC
# MAGIC # Load the model using the UC path and alias
# MAGIC alias = "champion"
# MAGIC UC_MODEL_NAME = f"{catalog_name}.{schema_name}.{agent_name}"
# MAGIC
# MAGIC # Load by alias
# MAGIC agent = mlflow.pyfunc.load_model(f"models:/{UC_MODEL_NAME}@{alias}")
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC   const el = document.getElementById("answer-1");
# MAGIC   if (!el) return;
# MAGIC
# MAGIC   const text = el.innerText;
# MAGIC
# MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC     navigator.clipboard.writeText(text)
# MAGIC       .then(() => alert("Copied to clipboard"))
# MAGIC       .catch(err => {
# MAGIC         console.error("Clipboard write failed:", err);
# MAGIC         fallbackCopy(text);
# MAGIC       });
# MAGIC   } else {
# MAGIC     fallbackCopy(text);
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC   const textarea = document.createElement("textarea");
# MAGIC   textarea.value = text;
# MAGIC   textarea.style.position = "fixed";
# MAGIC   textarea.style.left = "-9999px";
# MAGIC   document.body.appendChild(textarea);
# MAGIC   textarea.select();
# MAGIC   try {
# MAGIC     document.execCommand("copy");
# MAGIC     alert("Copied to clipboard");
# MAGIC   } catch (err) {
# MAGIC     console.error("Fallback copy failed:", err);
# MAGIC     alert("Could not copy to clipboard. Please copy manually.");
# MAGIC   } finally {
# MAGIC     document.body.removeChild(textarea);
# MAGIC   }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### A5. Load Evaluation Configuration
# MAGIC
# MAGIC Load the evaluation configuration that specifies different models for different evaluation tasks. This separation allows for optimized model selection based on evaluation type.
# MAGIC
# MAGIC **Loading Configs with MLflow:** `mlflow.models.ModelConfig` is used as a flexible configuration management tool for MLflow agents and models, enabling easy parameterization and portability of agent/model behaviors. You can initialize a ModelConfig from either a Python dictionary or a `.yaml` file.

# COMMAND ----------

## Load the evaluation configuration from the config file
development_config = "./artifacts/configs/agent_eval_config.yaml"

config = mlflow.models.ModelConfig(<FILL_IN>)

correctness_eval_endpoint = config.get(<FILL_IN>)
safety_endpoint = config.get(<FILL_IN>)
guidelines_endpoint = config.get(<FILL_IN>)

print(f"Correctness Endpoint: {correctness_eval_endpoint}")
print(f"Safety Endpoint: {safety_endpoint}")
print(f"Guidelines Endpoint: {guidelines_endpoint}")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC <code>
# MAGIC development_config = "./artifacts/configs/agent_eval_config.yaml"
# MAGIC
# MAGIC config = mlflow.models.ModelConfig(development_config=development_config)
# MAGIC
# MAGIC correctness_eval_endpoint = config.get('CORRECTNESS_EVAL_ENDPOINT')
# MAGIC safety_endpoint = config.get('SAFETY_EVAL_ENDPOINT')
# MAGIC guidelines_endpoint = config.get("GUIDELINES_ENDPOINT")
# MAGIC
# MAGIC print(f"Correctness Endpoint: {correctness_eval_endpoint}")
# MAGIC print(f"Safety Endpoint: {safety_endpoint}")
# MAGIC print(f"Guidelines Endpoint: {guidelines_endpoint}")
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC   const el = document.getElementById("answer-1");
# MAGIC   if (!el) return;
# MAGIC
# MAGIC   const text = el.innerText;
# MAGIC
# MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC     navigator.clipboard.writeText(text)
# MAGIC       .then(() => alert("Copied to clipboard"))
# MAGIC       .catch(err => {
# MAGIC         console.error("Clipboard write failed:", err);
# MAGIC         fallbackCopy(text);
# MAGIC       });
# MAGIC   } else {
# MAGIC     fallbackCopy(text);
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC   const textarea = document.createElement("textarea");
# MAGIC   textarea.value = text;
# MAGIC   textarea.style.position = "fixed";
# MAGIC   textarea.style.left = "-9999px";
# MAGIC   document.body.appendChild(textarea);
# MAGIC   textarea.select();
# MAGIC   try {
# MAGIC     document.execCommand("copy");
# MAGIC     alert("Copied to clipboard");
# MAGIC   } catch (err) {
# MAGIC     console.error("Fallback copy failed:", err);
# MAGIC     alert("Could not copy to clipboard. Please copy manually.");
# MAGIC   } finally {
# MAGIC     document.body.removeChild(textarea);
# MAGIC   }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. Understanding the NYC Taxi Dataset and Agent Functions

# COMMAND ----------

# MAGIC %md
# MAGIC ### B1. Test Agent Functions
# MAGIC
# MAGIC Let's test the agent's capabilities by calling it with different types of queries to understand how it uses the available functions.

# COMMAND ----------

def agent_payload(question: str):
    return [{"input": [{"role": "user", "content": question}]}]

# COMMAND ----------

## Test the agent with a query about trip information
## Use a query that would trigger the get_trip_info function
test_query_1 = <FILL_IN>
result_1 = agent.predict(agent_payload(test_query_1))
print(f"Query: {test_query_1}")
print(f"Response: {result_1}")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC <code>
# MAGIC test_query_1 = "What's the average trip distance for trips from zip code 10001 to 10002?"
# MAGIC result_1 = agent.predict(agent_payload(test_query_1))
# MAGIC print(f"Query: {test_query_1}")
# MAGIC print(f"Response: {result_1}")
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC   const el = document.getElementById("answer-1");
# MAGIC   if (!el) return;
# MAGIC
# MAGIC   const text = el.innerText;
# MAGIC
# MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC     navigator.clipboard.writeText(text)
# MAGIC       .then(() => alert("Copied to clipboard"))
# MAGIC       .catch(err => {
# MAGIC         console.error("Clipboard write failed:", err);
# MAGIC         fallbackCopy(text);
# MAGIC       });
# MAGIC   } else {
# MAGIC     fallbackCopy(text);
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC   const textarea = document.createElement("textarea");
# MAGIC   textarea.value = text;
# MAGIC   textarea.style.position = "fixed";
# MAGIC   textarea.style.left = "-9999px";
# MAGIC   document.body.appendChild(textarea);
# MAGIC   textarea.select();
# MAGIC   try {
# MAGIC     document.execCommand("copy");
# MAGIC     alert("Copied to clipboard");
# MAGIC   } catch (err) {
# MAGIC     console.error("Fallback copy failed:", err);
# MAGIC     alert("Could not copy to clipboard. Please copy manually.");
# MAGIC   } finally {
# MAGIC     document.body.removeChild(textarea);
# MAGIC   }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

## Test the agent with a fare calculation query
## Use a query that would trigger the calculate_fare_estimate function
test_query_2 = <FILL_IN>
result_2 = agent.predict(agent_payload(test_query_2))
print(f"Query: {test_query_2}")
print(f"Response: {result_2}")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC
# MAGIC <code>
# MAGIC test_query_2 = "What would be the estimated fare for a 5.2 mile trip with a base fare of $3.50?"
# MAGIC result_2 = agent.predict(agent_payload(test_query_2))
# MAGIC print(f"Query: {test_query_2}")
# MAGIC print(f"Response: {result_2}")
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Built-In Judges Implementation

# COMMAND ----------

# MAGIC %md
# MAGIC ### C1. Create Evaluation Dataset for Built-In Judges
# MAGIC
# MAGIC Create an evaluation dataset with two inputs, expected facts, and expected responses for testing correctness and safety judges. Part of the evaluation dataset has been filled out for you.
# MAGIC
# MAGIC **Hint:** If you get stuck, you can view a sample evaluation dataset in `./artifacts/evaluation_datasets/nyc_taxi_eval.json`.

# COMMAND ----------

## Create an evaluation dataset for built-in judges
## Include inputs and expectations with expected_facts for each query
eval_dataset_builtin = [
  {
    "inputs": {
      "input": [
        {
          "role": <FILL_IN>,
          "content": <FILL_IN>
        }
      ]
    },
    "expectations": {
      "expected_facts": [
        <FILL_IN>
      ]
    }
  },
  {
    "inputs": {
      "input": [
        {
          "role": <FILL_IN>,
          "content": <FILL_IN>
        }
      ]
    },
    "expectations": {
      "expected_facts": [
        <FILL_IN>
      ]
    }
  }
]

print("Created evaluation dataset for built-in judges:")
from pprint import pprint
pprint(eval_dataset_builtin)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC
# MAGIC
# MAGIC
# MAGIC <code>
# MAGIC eval_dataset_builtin = [
# MAGIC   {
# MAGIC     "inputs": {
# MAGIC       "input": [
# MAGIC         {
# MAGIC           "role": "user",
# MAGIC           "content": "What is the average fare for trips from zip code 10001 to 10002?"
# MAGIC         }
# MAGIC       ]
# MAGIC     },
# MAGIC     "expectations": {
# MAGIC       "expected_facts": [
# MAGIC         "Tool used is trip_info",
# MAGIC         "Pickup zip code is 10001",
# MAGIC         "Dropoff zip code is 10002",
# MAGIC         "Response includes average fare information"
# MAGIC       ]
# MAGIC     }
# MAGIC   },
# MAGIC   {
# MAGIC     "inputs": {
# MAGIC       "input": [
# MAGIC         {
# MAGIC           "role": "user",
# MAGIC           "content": "How many trips were taken from zip code 10003 to 10004?"
# MAGIC         }
# MAGIC       ]
# MAGIC     },
# MAGIC     "expectations": {
# MAGIC       "expected_facts": [
# MAGIC         "Tool used is trip_info",
# MAGIC         "Pickup zip code is 10003",
# MAGIC         "Dropoff zip code is 10004",
# MAGIC         "Response includes trip count",
# MAGIC         "Response includes 'Are there any additional questions I can help with?'"
# MAGIC       ]
# MAGIC     }
# MAGIC   }
# MAGIC ]
# MAGIC
# MAGIC print("Created evaluation dataset for built-in judges:")
# MAGIC from pprint import pprint
# MAGIC pprint(eval_dataset_builtin)
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### C2. Configure Built-In Judges
# MAGIC
# MAGIC Set up the Correctness and Safety judges using the configured endpoints.

# COMMAND ----------

## Import and configure the built-in judges
from mlflow.genai.scorers import <FILL_IN>, <FILL_IN>

## Create correctness judge instance
correctness_eval = <FILL_IN>(
    model=<FILL_IN>
)

## Create safety judge instance
safety_eval = <FILL_IN>(
    model=<FILL_IN>
)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC
# MAGIC
# MAGIC
# MAGIC <code>
# MAGIC from mlflow.genai.scorers import Correctness, Safety
# MAGIC
# MAGIC # Create correctness judge instance
# MAGIC correctness_eval = Correctness(
# MAGIC     model=correctness_eval_endpoint
# MAGIC )
# MAGIC
# MAGIC # Create safety judge instance
# MAGIC safety_eval = Safety(
# MAGIC     model=safety_endpoint
# MAGIC )
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### C3. Execute Built-In Judge Evaluation
# MAGIC
# MAGIC Run the evaluation using both correctness and safety judges simultaneously. Click on the **View evaluation results with MLflow** to inspect the results. 

# COMMAND ----------

## Execute evaluation with both built-in judges
builtin_results = mlflow.genai.evaluate(
    data=<FILL_IN>,
    predict_fn=<FILL_IN>,
    scorers=<FILL_IN>
)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC
# MAGIC
# MAGIC <code>
# MAGIC builtin_results = mlflow.genai.evaluate(
# MAGIC     data=eval_dataset_builtin,
# MAGIC     predict_fn=lambda input: agent.predict({"input": input}),
# MAGIC     scorers=[correctness_eval, safety_eval]
# MAGIC )
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### C4. Analyze Built-In Judge Results
# MAGIC
# MAGIC Examine the evaluation results and understand the scoring rationale using print statements and `builtin_results()`.

# COMMAND ----------

## Display the evaluation results and metrics
print(f"Run ID: {<FILL_IN>}")
print(f"Aggregated Metrics: {<FILL_IN>}")
print("\nDetailed Results:")
display(<FILL_IN>)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC
# MAGIC
# MAGIC <code>
# MAGIC print(f"Run ID: {builtin_results.run_id}")
# MAGIC print(f"Aggregated Metrics: {builtin_results.metrics}")
# MAGIC print("\nDetailed Results:")
# MAGIC display(builtin_results.result_df)
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### C5. Update and Iterate (Optional)
# MAGIC
# MAGIC Did your agent pass your expectations? If not, try updating the system prompt in `./artifacts/configs/nyc_taxi_agent_config.yaml` so that the agent aligns with your evaluation expectations. Iterate on top of this process all evaluations **Pass**. 
# MAGIC
# MAGIC For example, the default system prompt is 
# MAGIC
# MAGIC ```
# MAGIC You are an expert in answering questions regarding NYC Taxi data.
# MAGIC ```
# MAGIC
# MAGIC Which isn't very descriptive if, for example, we pass the question _What is the average fare for trips from zip code 10001 to 10002?_ and expect the following in our output 
# MAGIC - Tool used is trip_info,
# MAGIC - Pickup zip code is 10001,
# MAGIC - Dropoff zip code is 10002,
# MAGIC - Response includes 'Are there any additional questions I can help with?'
# MAGIC
# MAGIC then we might update our system prompt with _You are an expert in answering questions regarding NYC Taxi data. You will always respond with "Are there any additional questions I can help with?"_ (see screenshot below).
# MAGIC
# MAGIC ![update_system_prompt.png](./Includes/images/applying agent eval/update_system_prompt.png "update_system_prompt.png")

# COMMAND ----------

# MAGIC %md
# MAGIC After updating the prompt, you can redeploy your agent with the following code snippet.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <button onclick="copyBlock()">Copy to clipboard</button>
# MAGIC
# MAGIC <pre id="copy-block" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC <code>
# MAGIC import mlflow
# MAGIC import yaml
# MAGIC from mlflow.models.resources import DatabricksServingEndpoint, DatabricksFunction
# MAGIC
# MAGIC # Point to your existing YAML config file (the same one you pass as model_config)
# MAGIC CONFIG_YAML = "./artifacts/configs/nyc_taxi_agent_config.yaml"  # &lt;— set this
# MAGIC
# MAGIC # Load config from YAML
# MAGIC with open(CONFIG_YAML, "r") as f:
# MAGIC     cfg = yaml.safe_load(f)
# MAGIC
# MAGIC # Pull values from YAML (with sensible fallbacks)
# MAGIC CATALOG = cfg["CATALOG_NAME"]
# MAGIC SCHEMA = cfg["SCHEMA_NAME"]
# MAGIC MODEL_BASE_NAME = cfg.get("MODEL_NAME", "nyc_taxi_eval_agent")  # optional key in YAML; defaults to "nyc_agent"
# MAGIC UC_MODEL_NAME = f"{CATALOG}.{SCHEMA}.{MODEL_BASE_NAME}"
# MAGIC
# MAGIC LLM_ENDPOINT = cfg["LLM_ENDPOINT_NAME"]
# MAGIC
# MAGIC # Tools can be provided either as TOOL1/TOOL2, or as a TOOLS: [ ... ] list in YAML
# MAGIC if "TOOLS" in cfg and isinstance(cfg["TOOLS"], (list, tuple)) and len(cfg["TOOLS"]) &gt; 0:
# MAGIC     tool_names = [f"{CATALOG}.{SCHEMA}.{t}" for t in cfg["TOOLS"]]
# MAGIC else:
# MAGIC     tool1 = cfg.get("TOOL1")
# MAGIC     tool2 = cfg.get("TOOL2")
# MAGIC     tool_names = [f"{CATALOG}.{SCHEMA}.{t}" for t in [tool1, tool2] if t]
# MAGIC
# MAGIC # Build MLflow resources from YAML-driven values
# MAGIC resources = [DatabricksServingEndpoint(endpoint_name=LLM_ENDPOINT)] + [
# MAGIC     DatabricksFunction(function_name=t) for t in tool_names
# MAGIC ]
# MAGIC
# MAGIC # Same python model file you used before
# MAGIC AGENT_PY = "./artifacts/nyc_taxi_agent.py"
# MAGIC
# MAGIC # Optional alias (could also come from YAML via cfg.get("ALIAS", "champion"))
# MAGIC ALIAS = "challenger"
# MAGIC
# MAGIC mlflow.set_registry_uri("databricks-uc")  # ensure we register to UC
# MAGIC
# MAGIC with mlflow.start_run(tags={
# MAGIC     "training_type": "agent_eval_training",
# MAGIC     "model": LLM_ENDPOINT,
# MAGIC     "agent_type": "TOOL-CALLING",
# MAGIC     "agent_id": "agent2",
# MAGIC }):
# MAGIC     logged = mlflow.pyfunc.log_model(
# MAGIC         artifact_path="agent",
# MAGIC         python_model=AGENT_PY,
# MAGIC         model_config=CONFIG_YAML,  # the YAML you just edited (includes SYSTEM_PROMPT)
# MAGIC         artifacts={
# MAGIC             "agent_config": CONFIG_YAML,
# MAGIC             # "agent_eval_config": "/Workspace/Users/you/path/to/eval_config.yaml",  # optional
# MAGIC         },
# MAGIC         input_example={"input": [{"role": "user", "content": "hello"}]},
# MAGIC         pip_requirements=[
# MAGIC             "databricks-openai", "backoff", "pyyaml",
# MAGIC             # If you previously pinned databricks-connect, keep your pin here:
# MAGIC             # f"databricks-connect=={version('databricks-connect')}",
# MAGIC         ],
# MAGIC         resources=resources,
# MAGIC         registered_model_name=UC_MODEL_NAME,  # creates a new UC model version
# MAGIC     )
# MAGIC
# MAGIC new_version = logged.registered_model_version
# MAGIC print("New UC version:", new_version)
# MAGIC
# MAGIC # Optionally flip your alias to the new version:
# MAGIC from mlflow.tracking import MlflowClient
# MAGIC MlflowClient().set_registered_model_alias(
# MAGIC     name=UC_MODEL_NAME, alias=ALIAS, version=new_version
# MAGIC )
# MAGIC
# MAGIC # Load by alias
# MAGIC agent = mlflow.pyfunc.load_model(f"models:/{UC_MODEL_NAME}@{ALIAS}")
# MAGIC </code></pre>
# MAGIC
# MAGIC <script>
# MAGIC function copyBlock() {
# MAGIC   const el = document.getElementById("copy-block");
# MAGIC   if (!el) return;
# MAGIC
# MAGIC   const text = el.innerText;
# MAGIC
# MAGIC   // Preferred modern API
# MAGIC   if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC     navigator.clipboard.writeText(text)
# MAGIC       .then(() => alert("Copied to clipboard"))
# MAGIC       .catch(err => {
# MAGIC         console.error("Clipboard write failed:", err);
# MAGIC         fallbackCopy(text);
# MAGIC       });
# MAGIC   } else {
# MAGIC     fallbackCopy(text);
# MAGIC   }
# MAGIC }
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC   const textarea = document.createElement("textarea");
# MAGIC   textarea.value = text;
# MAGIC   textarea.style.position = "fixed";
# MAGIC   textarea.style.left = "-9999px";
# MAGIC   document.body.appendChild(textarea);
# MAGIC   textarea.select();
# MAGIC   try {
# MAGIC     document.execCommand("copy");
# MAGIC     alert("Copied to clipboard");
# MAGIC   } catch (err) {
# MAGIC     console.error("Fallback copy failed:", err);
# MAGIC     alert("Could not copy to clipboard. Please copy manually.");
# MAGIC   } finally {
# MAGIC     document.body.removeChild(textarea);
# MAGIC   }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC You can now go back to sections **C3** and **C4** and re-evaluate.

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Guideline Judges Implementation

# COMMAND ----------

# MAGIC %md
# MAGIC ### D1. Create Global Guidelines Dataset
# MAGIC
# MAGIC Create an evaluation dataset for testing global guidelines that apply uniformly to all responses.
# MAGIC
# MAGIC **Hint:** If you get stuck, you can view a sample evaluation dataset in `./artifacts/evaluation_datasets/nyc_taxi_guidelines_eval.json`.

# COMMAND ----------

## Create evaluation dataset for global guidelines
eval_dataset_guidelines = [
    {
        "inputs": <FILL_IN>
    }
]

print("Created evaluation dataset for global guidelines:")
pprint(eval_dataset_guidelines)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC
# MAGIC
# MAGIC <code>
# MAGIC eval_dataset_guidelines = [
# MAGIC   {
# MAGIC     "inputs": {
# MAGIC       "input": [
# MAGIC         {
# MAGIC           "role": "user",
# MAGIC           "content": "What is the average fare for trips from zip code 10001 to 10002?"
# MAGIC         }
# MAGIC       ]
# MAGIC     },
# MAGIC     "expectations": {
# MAGIC       "expected_facts": [
# MAGIC         "The average fare for trips between zip codes 10001 and 10002 is $12.50."
# MAGIC       ],
# MAGIC       "guidelines": [
# MAGIC         "The response should be professional and courteous",
# MAGIC         "The response should include specific numerical values when providing calculations or statistics",
# MAGIC         "The response should clearly indicate when it's using NYC taxi data"
# MAGIC     ]
# MAGIC     }
# MAGIC   }
# MAGIC ]
# MAGIC
# MAGIC print("Created evaluation dataset for global guidelines:")
# MAGIC pprint(eval_dataset_guidelines)
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### D2. Implement Global Guidelines Judge
# MAGIC
# MAGIC Create a global guidelines judge that ensures responses are professional and include specific formatting requirements.

# COMMAND ----------

## Import and configure the Guidelines judge
from mlflow.genai.scorers import <FILL_IN>

## Create a global guideline for professional responses
professional_guideline = <FILL_IN>(
    name=<FILL_IN>,
    guidelines=[
        <FILL_IN>,
        <FILL_IN>
    ],
    model_name=<FILL_IN>
)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC
# MAGIC <code>
# MAGIC from mlflow.genai.scorers import Guidelines
# MAGIC
# MAGIC # Create a global guideline for professional responses
# MAGIC professional_guideline = Guidelines(
# MAGIC     name="professional_response",
# MAGIC     guidelines=[
# MAGIC         "The response should be professional and courteous",
# MAGIC         "The response should include specific numerical values when providing calculations or statistics",
# MAGIC         "The response should clearly indicate when it's using NYC taxi data"
# MAGIC     ],
# MAGIC     model_name=guidelines_endpoint
# MAGIC )
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### D3. Execute Global Guidelines Evaluation
# MAGIC
# MAGIC Run the evaluation using the global guidelines judge. Click on the **View evaluation results with MLflow** to inspect the results. 

# COMMAND ----------

## Execute evaluation with global guidelines
guidelines_results = mlflow.genai.evaluate(
    data=<FILL_IN>,
    predict_fn=<FILL_IN>,
    scorers=<FILL_IN>
)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC
# MAGIC
# MAGIC <code>
# MAGIC guidelines_results = mlflow.genai.evaluate(
# MAGIC     data=eval_dataset_guidelines,
# MAGIC     predict_fn=lambda input: agent.predict({"input": input}),
# MAGIC     scorers=[professional_guideline]
# MAGIC )
# MAGIC </code>
# MAGIC
# MAGIC </pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. Comprehensive Evaluation Analysis

# COMMAND ----------

# MAGIC %md
# MAGIC ### E1. Compare Evaluation Results
# MAGIC
# MAGIC Analyze and compare results from different judge types to understand their strengths and use cases.

# COMMAND ----------

## Display results from all evaluation runs for comparison
print("=== BUILT-IN JUDGES RESULTS ===")
print(f"Run ID: {<FILL_IN>}")
print(f"Metrics: {<FILL_IN>}")
display(<FILL_IN>)

print("\n=== GLOBAL GUIDELINES RESULTS ===")
print(f"Run ID: {<FILL_IN>}")
print(f"Metrics: {<FILL_IN>}")
display(<FILL_IN>)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC <code>
# MAGIC print("=== BUILT-IN JUDGES RESULTS ===")
# MAGIC print(f"Run ID: {builtin_results.run_id}")
# MAGIC print(f"Metrics: {builtin_results.metrics}")
# MAGIC display(builtin_results.result_df)
# MAGIC
# MAGIC print("\n=== GLOBAL GUIDELINES RESULTS ===")
# MAGIC print(f"Run ID: {guidelines_results.run_id}")
# MAGIC print(f"Metrics: {guidelines_results.metrics}")
# MAGIC display(guidelines_results.result_df)
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### E2. Create Comprehensive Evaluation
# MAGIC
# MAGIC Combine multiple judge types in a single evaluation run to get comprehensive quality assessment.

# COMMAND ----------

## Create a comprehensive evaluation using multiple judge types
## Use the built-in dataset and combine correctness with global guidelines
comprehensive_results = mlflow.genai.evaluate(
    data=<FILL_IN>,
    predict_fn=<FILL_IN>,
    scorers=<FILL_IN>
)

print("=== COMPREHENSIVE EVALUATION RESULTS ===")
print(f"Run ID: {<FILL_IN>}")
print(f"Metrics: {<FILL_IN>}")
display(<FILL_IN>)

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC <details>
# MAGIC <summary style="cursor: pointer; padding: 10px; border: 1px solid #ccc; background-color: #f9f9f9; border-radius: 5px; font-weight: bold;">Click to view answer</summary>
# MAGIC
# MAGIC
# MAGIC <button onclick="copyAnswer1()">Copy to clipboard</button>
# MAGIC
# MAGIC
# MAGIC <pre id="answer-1" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC
# MAGIC <pre id="answer-13" style="font-family: ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, 'Liberation Mono', 'Courier New', monospace; border:1px solid #e5e7eb; border-radius:10px; background:#f8fafc; padding:14px 16px; font-size:0.85rem; line-height:1.35; white-space:pre;">
# MAGIC <code>
# MAGIC comprehensive_results = mlflow.genai.evaluate(
# MAGIC     data=eval_dataset_builtin,
# MAGIC     predict_fn=lambda input: agent.predict({"input": input}),
# MAGIC     scorers=[correctness_eval, professional_guideline]
# MAGIC )
# MAGIC
# MAGIC print("=== COMPREHENSIVE EVALUATION RESULTS ===")
# MAGIC print(f"Run ID: {comprehensive_results.run_id}")
# MAGIC print(f"Metrics: {comprehensive_results.metrics}")
# MAGIC display(comprehensive_results.result_df)
# MAGIC </code></pre>
# MAGIC
# MAGIC </details>
# MAGIC
# MAGIC <script>
# MAGIC function copyAnswer1() {
# MAGIC  const el = document.getElementById("answer-1");
# MAGIC  if (!el) return;
# MAGIC
# MAGIC
# MAGIC  const text = el.innerText;
# MAGIC
# MAGIC
# MAGIC  if (navigator.clipboard && navigator.clipboard.writeText) {
# MAGIC    navigator.clipboard.writeText(text)
# MAGIC      .then(() => alert("Copied to clipboard"))
# MAGIC      .catch(err => {
# MAGIC        console.error("Clipboard write failed:", err);
# MAGIC        fallbackCopy(text);
# MAGIC      });
# MAGIC  } else {
# MAGIC    fallbackCopy(text);
# MAGIC  }
# MAGIC }
# MAGIC
# MAGIC
# MAGIC function fallbackCopy(text) {
# MAGIC  const textarea = document.createElement("textarea");
# MAGIC  textarea.value = text;
# MAGIC  textarea.style.position = "fixed";
# MAGIC  textarea.style.left = "-9999px";
# MAGIC  document.body.appendChild(textarea);
# MAGIC  textarea.select();
# MAGIC  try {
# MAGIC    document.execCommand("copy");
# MAGIC    alert("Copied to clipboard");
# MAGIC  } catch (err) {
# MAGIC    console.error("Fallback copy failed:", err);
# MAGIC    alert("Could not copy to clipboard. Please copy manually.");
# MAGIC  } finally {
# MAGIC    document.body.removeChild(textarea);
# MAGIC  }
# MAGIC }
# MAGIC </script>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ## F. Conclusion
# MAGIC
# MAGIC In this lab, you have successfully implemented a comprehensive evaluation framework for AI agents using MLflow's built-in and guideline judges. You learned how to:
# MAGIC
# MAGIC - Configure and execute multiple types of judges for different evaluation needs
# MAGIC - Create properly structured evaluation datasets for various judge types
# MAGIC - Analyze evaluation results using MLflow's tracing and result analysis capabilities
# MAGIC - Apply best practices for evaluation configuration and model management
# MAGIC
# MAGIC These evaluation techniques provide the foundation for ensuring your AI agents meet quality standards and perform reliably in production environments. The combination of objective built-in judges and flexible guideline judges enables comprehensive quality assessment that can adapt to your specific business requirements.

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>