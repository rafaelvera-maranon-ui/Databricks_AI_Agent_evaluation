# Databricks notebook source
!pip install --upgrade "mlflow[databricks]==3.7.0"
!pip install "backoff==2.2.1"
!pip install "databricks-openai==0.8.0"
!pip install "mlflow==3.8.1"
!pip install "openai==2.16.0"
!pip install "databricks-connect>=16.1"
# Install prerequisites
!pip install "databricks-agents>=1.1.0"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

import json
from pathlib import Path 
import mlflow 
from mlflow.entities import SpanType
from mlflow.tracking import MlflowClient
from databricks import agents
from mlflow.models.resources import DatabricksFunction, DatabricksServingEndpoint
from importlib.metadata import version
from typing import Tuple, Dict, Any
import warnings


class DemoSetup:
    def __init__(
        self,
        catalog_name: str = None,
        schema_name: str = "demo_agent_eval",
        agent_name: str = "airbnb_eval_agent",
        experiment_name: str = "feedback_experiment",
        feedback_endpoint: str = "databricks:/databricks-gpt-5-mini",
        username: str = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get(),
        model_alias: str = "champion",
        session_id: str = "feedback-session-001",
        llm_endpoint_name: str = "databricks-gpt-oss-20b",
        deployed_agent_exp_name: str = "airbnb_experiment"
    ):
        if catalog_name:
            self.catalog_name = build_user_catalog(catalog_forced=catalog_name)
        else: 
            self.catalog_name = build_user_catalog()
        self.schema_name = schema_name
        self.agent_name = agent_name
        self.uc_model_name = f"{self.catalog_name}.{self.schema_name}.{self.agent_name}"

        self.model_alias = model_alias

        self.username = username

        self.experiment_name = f"/Users/{self.username}/{experiment_name}"

        self.feedback_endpoint = feedback_endpoint

        self.session_id = session_id
        
        self.llm_endpoint_name = llm_endpoint_name
        
        # Store deployment info
        self.deployment = None
        self.endpoint_name = None

        self.deployed_agent_exp_name = deployed_agent_exp_name

    def run(self) -> None:
        print("=" * 60)
        print("Starting Databricks Agent Demo Setup")
        print("=" * 60)

        self.dev_lab_setup()

        queries = self.queries()
        
        for query in queries:
            print(f"Running query: {query}")
            self.gen_trace_data(query)
        
    def dev_lab_setup(self) -> None:
        spark.sql(f"USE CATALOG {self.catalog_name}")
        spark.sql(f"USE SCHEMA {self.schema_name}")

        # Look up by fully qualified path in Databricks (preferred)
        print("Check if experiment already exists...")
        exp = mlflow.get_experiment_by_name(self.experiment_name)
        self.experiment_id = exp.experiment_id
        if exp is None:
            print(f"Experiment not found: {self.experiment_name}. Creating a new experiment.")
        else:
            print(f"Experiment already exists. Deleting experiment and starting from scratch.")
            client = MlflowClient()
            client.delete_experiment(self.experiment_id)
            print(f"Deleted experiment {self.experiment_id} ({self.experiment_name})")

    def get_env_vars(self):
        print(f"Using catalog: {self.catalog_name}")
        print(f"Using schema: {self.schema_name}")
        print(f"Getting agent name: {self.agent_name}")
        print(f"Getting experiment ID: {self.experiment_id}")
        model_username_string = self.username.split('@')[0].replace(".","_")+"_agent"
        deployed_model_experiment_loc = f"/Workspace/Users/{self.username}/{self.deployed_agent_exp_name}"
        return self.catalog_name, self.schema_name, self.agent_name, model_username_string, deployed_model_experiment_loc

    def load_agent(self):
        mlflow.openai.autolog()
        mlflow.set_tracking_uri("databricks")
        mlflow.set_experiment(self.experiment_name)
        mlflow.set_registry_uri("databricks-uc")
        agent = mlflow.pyfunc.load_model(f"models:/{self.uc_model_name}@{self.model_alias}")

        return agent
    
    def queries(self):
        return [
            "How many Entire home/apt listings are in the Mission neighborhood?",
            "Count the number of Private room listings in Nob Hill.",
            "What is the average listing price in Haight Ashbury?"
        ]
        
    def gen_trace_data(self, query: str) -> Tuple[Dict[str, Any]]:
        agent = self.load_agent()
        with mlflow.start_span(
            name = "populate_agent_trace",
            span_type=SpanType.AGENT) as span:
            mlflow.update_current_trace(
                metadata={
                    "mlflow.trace.session": self.session_id,
                    "mlflow.trace.user": self.username
                },
                tags={
                    "training_type": "human_feedback_training",
                    "model": self.feedback_endpoint,
                    "agent_type": "TOOL-CALLING"
                }
            )

            query_payload = [
                {"input": [{"role": "user", "content": query}]}]

            response = agent.predict(query_payload)

            # log input and output at the span-level for visability
            span.set_inputs({"query": query})
            span.set_outputs({"response": response})
            trace_id = span.trace_id