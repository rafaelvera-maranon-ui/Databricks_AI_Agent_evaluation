# Databricks notebook source
!pip install --upgrade "mlflow[databricks]==3.7.0"
!pip install "backoff==2.2.1"
!pip install "databricks-openai==0.8.0"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

import json
from pathlib import Path
import mlflow 
from mlflow.tracking import MlflowClient

class DemoSetup:
    def __init__(
        self,
        catalog_name: str = None,
        schema_name: str = "demo_agent_eval",
        agent_name = "airbnb_eval_agent",
        session_id = "custom-eval-001",
        experiment_name = "airbnb_experiment",
    ):
        try: 
            if catalog_name:
                self.catalog_name = build_user_catalog(catalog_forced=catalog_name)
            else: 
                self.catalog_name = build_user_catalog()
        except:
            print(f"catalog {self.catalog_name} already exists.")
        self.schema_name = schema_name
        self.agent_name = agent_name

        self.session_id = session_id

        self.username = dbutils.notebook.entry_point.getDbutils().notebook().getContext().userName().get()

        self.experiment_name = f"/Users/{self.username}/{experiment_name}"

    def run(self) -> None:
        print("=" * 60)
        print("Starting Databricks Agent Demo Setup")
        print("=" * 60)

        self.dev_lab_setup()

    def dev_lab_setup(self) -> None:
        spark.sql(f"USE CATALOG {self.catalog_name}")
        spark.sql(f"CREATE SCHEMA IF NOT EXISTS {self.schema_name}")
        spark.sql(f"USE SCHEMA {self.schema_name}")
        print("Check if experiment already exists...")
        exp = mlflow.get_experiment_by_name(self.experiment_name)
        self.experiment_id = exp.experiment_id

    def get_env_vars(self):
        print(f"Using catalog: {self.catalog_name}")
        print(f"Using schema: {self.schema_name}")
        print(f"Getting agent name: {self.agent_name}")
        return self.catalog_name, self.schema_name, self.agent_name, self.session_id, self.experiment_id