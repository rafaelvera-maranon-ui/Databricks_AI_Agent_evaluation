# Databricks notebook source
!pip install --upgrade "mlflow[databricks]==3.8.1"
!pip install "backoff==2.2.1"
!pip install "databricks-openai==0.8.0"

# COMMAND ----------

dbutils.library.restartPython()

# COMMAND ----------

# MAGIC %run ./Classroom-Setup-Common

# COMMAND ----------

import json
from pathlib import Path


class DemoSetup:
    def __init__(
        self,
        catalog_name: str = None,
        schema_name: str = "demo_agent_eval",
        agent_name = "airbnb_eval_agent"
    ):
        if catalog_name:
            self.catalog_name = build_user_catalog(catalog_forced=catalog_name)
        else: 
            self.catalog_name = build_user_catalog()
        self.schema_name = schema_name
        self.agent_name = agent_name

    def run(self) -> None:
        print("=" * 60)
        print("Starting Databricks Agent Demo Setup")
        print("=" * 60)

        self.dev_lab_setup()

    def dev_lab_setup(self) -> None:
        spark.sql(f"USE CATALOG {self.catalog_name}")
        spark.sql(f"USE SCHEMA {self.schema_name}")

    def get_env_vars(self):
        print(f"Using catalog: {self.catalog_name}")
        print(f"Using schema: {self.schema_name}")
        print(f"Getting agent name: {self.agent_name}")
        return self.catalog_name, self.schema_name, self.agent_name