# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Lecture - Evaluation with MLflow
# MAGIC ## Overview
# MAGIC
# MAGIC Building production-ready AI agents requires more than just implementation—it demands rigorous evaluation to validate correctness, measure quality, and identify failure modes. MLflow provides a comprehensive evaluation framework specifically designed for generative AI applications, offering automated judges, tracing capabilities, and systematic assessment tools.
# MAGIC
# MAGIC In this lecture, we'll examine the challenges unique to evaluating AI agents, explore MLflow's evaluation architecture, and understand the different types of judges and scorers available. This foundation prepares you for hands-on implementation in the subsequent demonstrations where you'll evaluate real agents against quality metrics.
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this lecture, you will be able to:
# MAGIC - Explain why traditional software testing approaches are insufficient for AI agents
# MAGIC - Describe MLflow's evaluation framework architecture and key components
# MAGIC - Distinguish between different types of evaluation judges (built-in, guideline, custom)
# MAGIC - Identify when to use offline versus online evaluation strategies
# MAGIC - Understand the role of tracing in agent evaluation and debugging
# MAGIC - Recognize best practices for creating comprehensive evaluation datasets

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. The Challenge of Evaluating AI Agents

# COMMAND ----------

# MAGIC %md
# MAGIC ### A1. Why Traditional Testing Falls Short
# MAGIC
# MAGIC Traditional software testing relies on deterministic inputs and expected outputs. You write unit tests, integration tests, and end-to-end tests that verify your code produces the exact same result every time given the same input. This approach works well for classical software systems where behavior is predictable and reproducible.
# MAGIC
# MAGIC **AI agents fundamentally break this paradigm:**
# MAGIC
# MAGIC - **Non-determinism**: LLMs introduce randomness through temperature and sampling, meaning the same input can produce different outputs
# MAGIC - **Emergent behavior**: Agents make autonomous decisions about tool usage and reasoning paths that weren't explicitly programmed
# MAGIC - **Context dependency**: Agent responses depend on retrieved documents, conversation history, and external data sources
# MAGIC - **Qualitative assessment**: Success often requires subjective judgment about helpfulness, tone, or appropriateness rather than exact string matching
# MAGIC
# MAGIC Consider a simple example: An agent answering "What's the weather in San Francisco?" might respond:
# MAGIC - "It's currently 65°F and sunny in San Francisco."
# MAGIC - "San Francisco weather: 65 degrees, clear skies."
# MAGIC - "The temperature in SF is 65°F with no clouds."
# MAGIC
# MAGIC All three responses are correct, helpful, and appropriate—yet none match exactly. Traditional assertion-based testing (`assert output == "expected_response"`) would fail on all three.

# COMMAND ----------

# MAGIC %md
# MAGIC ### A2. The Agent Evaluation Challenge
# MAGIC ![the-agent-evaluation-challenge.png](./Includes/images/Evaluation with MLflow/the-agent-evaluation-challenge.png "the-agent-evaluation-challenge.png")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### EXPAND FOR ADDITIONAL NOTES
# MAGIC
# MAGIC <details>
# MAGIC
# MAGIC Evaluating AI agents introduces unique complexities beyond traditional software:
# MAGIC
# MAGIC **Multi-step reasoning**: Agents may invoke multiple tools, retrieve various documents, and build complex reasoning chains. Evaluation must assess not just the final answer but the quality of intermediate steps.
# MAGIC
# MAGIC **Tool calling accuracy**: Did the agent select the right tools? Did it pass appropriate parameters? Did it correctly interpret tool results?
# MAGIC
# MAGIC **Retrieval quality**: For RAG-based agents, evaluation must verify that retrieved documents contain relevant information and that the agent correctly synthesizes information from multiple sources.
# MAGIC
# MAGIC **Safety and alignment**: Agents must avoid harmful outputs, respect user boundaries, and decline inappropriate requests—qualities that require sophisticated evaluation beyond simple pass/fail tests.
# MAGIC
# MAGIC **Real-world variability**: Production agents encounter diverse user queries, unexpected phrasings, and edge cases that are difficult to anticipate during development.
# MAGIC
# MAGIC These challenges demand a more sophisticated evaluation framework specifically designed for the probabilistic, contextual nature of AI agents.
# MAGIC
# MAGIC </details>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### A3. Evaluation as a Continuous Process
# MAGIC ![evaluation-as-continuous-process.png](./Includes/images/Evaluation with MLflow/evaluation-as-continuous-process.png "evaluation-as-continuous-process.png")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### EXPAND FOR ADDITIONAL NOTES
# MAGIC
# MAGIC <details>
# MAGIC Unlike traditional software where comprehensive test suites provide stable quality signals, AI agent evaluation is an ongoing process:
# MAGIC
# MAGIC **Development phase**: Rapid iteration requires frequent evaluation to validate that changes improve quality without introducing regressions.
# MAGIC
# MAGIC **Pre-deployment validation**: Comprehensive evaluation across diverse test cases ensures agents meet quality bars before production release.
# MAGIC
# MAGIC **Production monitoring**: Continuous evaluation of live interactions identifies quality degradation, emerging failure patterns, and opportunities for improvement.
# MAGIC
# MAGIC This continuous evaluation cycle means your evaluation infrastructure must be scalable, automated, and integrated into your development workflow—precisely what MLflow provides.
# MAGIC </details>
# MAGIC

# COMMAND ----------

# MAGIC %md
# MAGIC ### A4. Preparing for Evaluation (Why Prep Matters)
# MAGIC
# MAGIC Before using MLflow's evaluation framework, it's important to make evaluation both purposeful and reproducible. AI agents are non-deterministic and context-dependent, so traditional assertion-style tests fall short. Instead, effective evaluation requires defining quality dimensions, assembling representative datasets, and enabling tracing so judges can assess not just answers, but how those answers were produced.
# MAGIC
# MAGIC By clarifying goals, curating datasets, and selecting appropriate judges up front, you create a feedback loop where metrics reflect real user needs and failures are diagnosable through traces and rationales—not just pass/fail scores.

# COMMAND ----------

# MAGIC %md
# MAGIC ### A5. Designing Your Evaluation Dataset
# MAGIC ![designing-evaluation-datasets.png](./Includes/images/Evaluation with MLflow/designing-evaluation-datasets.png "designing-evaluation-datasets.png")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### EXPAND FOR ADDITIONAL NOTES
# MAGIC <details>
# MAGIC Your evaluation dataset defines what you test and how trustworthy your signals will be. At minimum, it should include inputs (queries) and, where appropriate, expected answers, per-row guidelines, and metadata that reflects retrieval and tool usage.
# MAGIC
# MAGIC **Key principles:**
# MAGIC
# MAGIC - **Representativeness:** Include common, high-impact user queries so offline results generalize to production.
# MAGIC - **Edge cases:** Add ambiguous, out-of-scope, and adversarial prompts to surface failure modes early.
# MAGIC - **Diversity:** Vary length, complexity, domain, and user expertise to expose blind spots in reasoning and retrieval.
# MAGIC - **Ground truth and/or guidelines:** Use expected answers or fact sets for objective questions; use natural-language guidelines where style, policy, or completeness matter.
# MAGIC - **Storage and versioning:** Store datasets as JSON or DataFrames (ideally in Delta/Unity Catalog) so they evolve alongside your agent. Consider using EvaluationDataset service for versioning and lineage.
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC ### A6. Operational Setup (MLflow + Governance)
# MAGIC
# MAGIC Establish consistent scaffolding so results are comparable and auditable.
# MAGIC
# MAGIC - **MLflow experiments and runs:** Use stable experiment names; tag runs with agent version, dataset version, and parameters; compare metrics and inspect per-example artifacts in the UI.
# MAGIC - **Unity Catalog integration:** Govern datasets and traces with access control, versioning, and lineage; register agents and dependencies for end-to-end traceability.
# MAGIC - **Production feedback loop (plan ahead):** Once deployed, enable AI Gateway inference tables to log requests, responses, and traces for monitoring and for mining new evaluation examples.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## ⚠️ Demo Checkpoint
# MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC     <span style="font-size: 24px;"></span>
# MAGIC     <div>
# MAGIC       <strong style="color: #e65100; font-size: 1.1em;">Demo Checkpoint</strong>
# MAGIC       <p style="margin: 8px 0 0 0; color: #333;">Navigate to the first Demo titled <strong>01 Demo - Agent Setup</strong> and initiate the setup of your agent and UC assets that will be used throughout this training. When you are finished, navigate back to this lecture notebook and continue learning.</p>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. MLflow's Evaluation Framework

# COMMAND ----------

# MAGIC %md
# MAGIC ![preparing-for-evaluation.png](./Includes/images/Evaluation with MLflow/preparing-for-evaluation.png "preparing-for-evaluation.png")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### EXPAND FOR ADDITIONAL NOTES
# MAGIC <details>
# MAGIC MLflow is an open source platform for managing the full machine learning lifecycle, and it now natively supports OpenTelemetry for advanced observability and monitoring, allowing seamless tracing and metrics export to external observability platforms.
# MAGIC
# MAGIC ### MLflow Overview
# MAGIC - MLflow is developed by Databricks to manage the entire machine learning lifecycle: experimentation tracking, model registry, deployment, and production monitoring. 
# MAGIC - It supports both traditional ML and GenAI workloads and works with multiple frameworks and libraries.
# MAGIC - The managed MLflow version in Databricks adds enterprise capabilities, including security and scalability. 
# MAGIC
# MAGIC ### Core features in recent versions (MLflow 3.x):
# MAGIC
# MAGIC - Experiment tracking with parameters, metrics, and model lineage
# MAGIC - Model Registry for versioning, stage transitions, and annotations (integrated with Unity Catalog)
# MAGIC - Model deployment for batch, streaming, and real-time inference
# MAGIC - Real-time tracing server (MLflow Tracing) for instant observability
# MAGIC - Production monitoring including automatic scoring of GenAI traces
# MAGIC - Deep support for prompt engineering and GenAI evaluation workflows
# MAGIC
# MAGIC ### OpenTelemetry Integration
# MAGIC - OpenTelemetry is an open standard for telemetry data collection and export, widely adopted for observability across cloud-native systems.
# MAGIC - MLflow traces are fully compatible with OpenTelemetry trace specifications, allowing export to popular solutions (e.g., Datadog, New Relic, Grafana, Splunk).
# MAGIC - MLflow supports three trace export modes:
# MAGIC     - MLflow tracking only (default): sends traces to MLflow Tracking Server
# MAGIC     - OpenTelemetry only: sends traces to an OpenTelemetry Collector
# MAGIC     - Dual export: sends traces to both MLflow and an OpenTelemetry Collector 
# MAGIC
# MAGIC
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC ### B1. Core Architecture
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC <img src="https://docs.databricks.com/aws/en/assets/images/flowchart-00c729ac75207b58d9c2243583a30d5a.png" alt="MLFlow Evaluation">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### EXPAND FOR ADDITIONAL NOTES
# MAGIC <details>
# MAGIC
# MAGIC MLflow provides a comprehensive evaluation framework designed specifically for generative AI applications. The architecture centers on three fundamental components:
# MAGIC
# MAGIC **1. Evaluation Datasets**
# MAGIC
# MAGIC Your evaluation dataset defines what you're testing. At minimum, it contains inputs (queries or requests to your agent). Optionally, it can include:
# MAGIC - **Outputs**: Pre-generated agent responses for faster evaluation without re-running inference
# MAGIC - **Expectations**: Ground truth information such as expected facts, expected responses, or per-row guidelines
# MAGIC - **Traces**: Complete execution traces for analyzing multi-step agent behavior
# MAGIC - **Metadata**: Additional context like user preferences, conversation history, or retrieved documents
# MAGIC
# MAGIC Datasets are typically stored as JSON files or Pandas DataFrames for easy manipulation and versioning.
# MAGIC
# MAGIC **2. Scorers (Judges)**
# MAGIC
# MAGIC Scorers evaluate your agent's outputs against defined criteria. MLflow provides multiple scorer types:
# MAGIC - **Built-in judges**: Research-validated LLM-based assessments for common criteria like correctness, relevance, and safety
# MAGIC - **Guideline judges**: Custom business rules expressed in natural language
# MAGIC - **Code-based scorers**: Python functions for deterministic evaluation (length checks, format validation, etc.)
# MAGIC - **Custom LLM judges**: Your own LLM-based evaluation logic for specialized requirements
# MAGIC
# MAGIC **3. Predict Function**
# MAGIC
# MAGIC The predict function generates outputs for your evaluation dataset. This can be:
# MAGIC - Your agent's prediction method (for evaluating on-the-fly)
# MAGIC - A lambda that transforms inputs to the format your agent expects
# MAGIC - Omitted entirely if you're evaluating pre-generated outputs
# MAGIC
# MAGIC These three components come together in `mlflow.genai.evaluate()`, which orchestrates the evaluation process, collects metrics, and logs comprehensive results for analysis.
# MAGIC </details>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B2. The `mlflow.genai.evaluate()` Function
# MAGIC
# MAGIC <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
# MAGIC   <colgroup>
# MAGIC     <col style="width: 60%;">
# MAGIC     <col style="width: 40%;">
# MAGIC   </colgroup>
# MAGIC   <tr>
# MAGIC     <td style="vertical-align: top; padding-right: 20px;">
# MAGIC       <div class="code-block-dark" data-language="python">
# MAGIC import mlflow
# MAGIC from mlflow.genai.scorers import Correctness
# MAGIC
# MAGIC results = mlflow.genai.evaluate(
# MAGIC     data=eval_dataset,                  # DataFrame, list[dict], or EvaluationDataset
# MAGIC     scorers=[Correctness()],            # Built-in and/or custom scorers
# MAGIC     predict_fn=my_app,                  # Optional: direct evaluation
# MAGIC     # model_id="models:/my-app/1",      # Optional: link to versioned app
# MAGIC )
# MAGIC       </div>
# MAGIC     </td>
# MAGIC     <td style="vertical-align: top; padding-left: 20px; font-size: 16px;">
# MAGIC       <p>The <code>mlflow.genai.evaluate()</code> function serves as the central orchestration point for agent evaluation. Understanding its behavior is critical for effective evaluation workflows.</p>
# MAGIC       <p><strong>Key parameters:</strong></p>
# MAGIC       <ul>
# MAGIC         <li><code>data</code>: Your evaluation dataset</li>
# MAGIC         <li><code>scorers</code>: List of scoring functions</li>
# MAGIC         <li><code>predict_fn</code>: Your agent/app function</li>
# MAGIC         <li><code>model_id</code>: Optional model reference</li>
# MAGIC       </ul>
# MAGIC     </td>
# MAGIC   </tr>
# MAGIC </table>
# MAGIC
# MAGIC <style id="prism-inline-css">
# MAGIC /* Prism Tomorrow Night theme - inlined */
# MAGIC code[class*="language-"],pre[class*="language-"]{color:#ccc;background:0 0;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;font-size:1em;text-align:left;white-space:pre;word-spacing:normal;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}pre[class*="language-"]{padding:1em;margin:.5em 0;overflow:auto}:not(pre)>code[class*="language-"],pre[class*="language-"]{background:#2d2d2d}:not(pre)>code[class*="language-"]{padding:.1em;border-radius:.3em;white-space:normal}.token.comment,.token.block-comment,.token.prolog,.token.doctype,.token.cdata{color:#999}.token.punctuation{color:#ccc}.token.tag,.token.attr-name,.token.namespace,.token.deleted{color:#e2777a}.token.function-name{color:#6196cc}.token.boolean,.token.number,.token.function{color:#f08d49}.token.property,.token.class-name,.token.constant,.token.symbol{color:#f8c555}.token.selector,.token.important,.token.atrule,.token.keyword,.token.builtin{color:#cc99cd}.token.string,.token.char,.token.attr-value,.token.regex,.token.variable{color:#7ec699}.token.operator,.token.entity,.token.url{color:#67cdcc}.token.important,.token.bold{font-weight:700}.token.italic{font-style:italic}.token.entity{cursor:help}.token.inserted{color:green}
# MAGIC </style>
# MAGIC
# MAGIC <script>
# MAGIC // Minimal Prism core + Python/SQL - inlined (no external requests)
# MAGIC (function(){
# MAGIC var Prism = window.Prism = {
# MAGIC     languages: {},
# MAGIC     highlight: function(text, grammar) {
# MAGIC         return this.tokenize(text, grammar).map(function(token) {
# MAGIC             if (typeof token === 'string') return token;
# MAGIC             var type = token.type, content = token.content;
# MAGIC             return '<span class="token ' + type + '">' + content + '</span>';
# MAGIC         }).join('');
# MAGIC     },
# MAGIC     tokenize: function(text, grammar) {
# MAGIC         var tokens = [text];
# MAGIC         for (var key in grammar) {
# MAGIC             var pattern = grammar[key];
# MAGIC             for (var i = 0; i < tokens.length; i++) {
# MAGIC                 if (typeof tokens[i] !== 'string') continue;
# MAGIC                 var match, matches = [];
# MAGIC                 pattern.lastIndex = 0;
# MAGIC                 while ((match = pattern.exec(tokens[i])) !== null) {
# MAGIC                     matches.push({index: match.index, length: match[0].length, value: match[0]});
# MAGIC                 }
# MAGIC                 if (!matches.length) continue;
# MAGIC                 var newTokens = [];
# MAGIC                 var lastIndex = 0;
# MAGIC                 matches.forEach(function(m) {
# MAGIC                     if (m.index > lastIndex) newTokens.push(tokens[i].substring(lastIndex, m.index));
# MAGIC                     newTokens.push({type: key, content: m.value});
# MAGIC                     lastIndex = m.index + m.length;
# MAGIC                 });
# MAGIC                 if (lastIndex < tokens[i].length) newTokens.push(tokens[i].substring(lastIndex));
# MAGIC                 tokens.splice.apply(tokens, [i, 1].concat(newTokens));
# MAGIC             }
# MAGIC         }
# MAGIC         return tokens;
# MAGIC     },
# MAGIC     highlightElement: function(element) {
# MAGIC         var code = element.textContent;
# MAGIC         var lang = element.className.match(/language-(\w+)/);
# MAGIC         lang = lang ? lang[1] : 'python';
# MAGIC         var grammar = this.languages[lang] || this.languages.python;
# MAGIC         element.innerHTML = this.highlight(code, grammar);
# MAGIC     }
# MAGIC };
# MAGIC
# MAGIC // Python grammar
# MAGIC Prism.languages.python = {
# MAGIC     'comment': /#.*/g,
# MAGIC     'string': /("""[\s\S]*?"""|'''[\s\S]*?'''|"[^"]*"|'[^']*')/g,
# MAGIC     'keyword': /\b(import|from|def|class|return|if|elif|else|for|while|try|except|finally|with|as|pass|break|continue|yield|lambda|async|await|None|True|False)\b/g,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[-+*/%=<>!&|^~]+/g,
# MAGIC     'punctuation': /[{}[\];(),.]/g
# MAGIC };
# MAGIC
# MAGIC // SQL grammar
# MAGIC Prism.languages.sql = {
# MAGIC     'comment': /--.*|\/\*[\s\S]*?\*\//g,
# MAGIC     'string': /'[^']*'/g,
# MAGIC     'keyword': /\b(SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|GRANT|TABLE|CATALOG|TO|ON|LIMIT|AND|OR|NOT|IN|AS|IS|NULL|JOIN|LEFT|RIGHT|INNER|OUTER|GROUP|BY|ORDER|HAVING|DISTINCT|COUNT|SUM|AVG|MAX|MIN)\b/gi,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[<>!=]=?|[-+*/%]|\b(LIKE|BETWEEN)\b/gi,
# MAGIC     'punctuation': /[;,.()]/g
# MAGIC };
# MAGIC
# MAGIC // Auto-process code blocks
# MAGIC document.querySelectorAll('.code-block-dark').forEach(function(block) {
# MAGIC     if (block.getAttribute('data-processed')) return;
# MAGIC     block.setAttribute('data-processed', 'true');
# MAGIC     var lang = block.getAttribute('data-language') || 'python';
# MAGIC     var code = block.textContent.trim();
# MAGIC     var id = 'code-dark-' + Math.random().toString(36).substr(2, 9);
# MAGIC     block.innerHTML = 
# MAGIC         '<div style="position:relative;margin:16px 0;max-width:100%;">' +
# MAGIC             '<button class="copy-btn" style="position:absolute;top:8px;right:8px;padding:4px 12px;font-size:12px;background:#555;color:#fff;border:1px solid #666;border-radius:4px;cursor:pointer;z-index:10;">Copy</button>' +
# MAGIC             '<pre style="background:#2d2d2d;border-radius:8px;padding:16px;padding-top:40px;overflow-x:auto;margin:0;border:1px solid #444;max-width:100%;box-sizing:border-box;"><code id="' + id + '" class="language-' + lang + '" style="font-family:Consolas,Monaco,monospace;font-size:13px;word-wrap:break-word;white-space:pre-wrap;"></code></pre>' +
# MAGIC         '</div>';
# MAGIC     var codeEl = document.getElementById(id);
# MAGIC     codeEl.textContent = code;
# MAGIC     Prism.highlightElement(codeEl);
# MAGIC     block.querySelector('.copy-btn').onclick = function() {
# MAGIC         var t = document.createElement('textarea');
# MAGIC         t.value = code;
# MAGIC         document.body.appendChild(t);
# MAGIC         t.select();
# MAGIC         document.execCommand('copy');
# MAGIC         document.body.removeChild(t);
# MAGIC         this.textContent = '✓ Copied!';
# MAGIC         setTimeout(() => this.textContent = 'Copy', 2000);
# MAGIC     };
# MAGIC });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### B3. Evaluation Workflow
# MAGIC
# MAGIC **Evaluation workflow:**
# MAGIC
# MAGIC 1. **Data loading**: MLflow loads your evaluation dataset and validates its structure
# MAGIC 2. **Output generation**: If `predict_fn` is provided, MLflow calls it for each input to generate outputs
# MAGIC 3. **Trace creation**: Each prediction creates an MLflow trace when your predict_fn is instrumented (e.g., with `@mlflow.trace` or `mlflow.openai.autolog`) or when evaluating endpoints with `mlflow.genai.to_predict_fn`. For "answer sheet" mode, evaluate constructs traces from inputs/outputs even without running the app.
# MAGIC 4. **Scorer execution**: Each scorer evaluates the inputs/outputs/traces according to its logic
# MAGIC 5. **Result aggregation**: Individual scores are aggregated into summary metrics
# MAGIC 6. **Logging**: Results are logged to MLflow for analysis and comparison
# MAGIC
# MAGIC **Return value:**
# MAGIC
# MAGIC The function returns an `EvaluationResult` object containing:
# MAGIC - **run_id**: Unique identifier for this evaluation run
# MAGIC - **metrics**: Aggregated metrics across all examples (e.g., average score, pass rate)
# MAGIC
# MAGIC **Accessing per-example results:**
# MAGIC
# MAGIC In MLflow 3, per-example results are accessed via traces rather than a result_df attribute:
# MAGIC ```python
# MAGIC eval_traces = mlflow.search_traces(run_id=results.run_id)
# MAGIC ```
# MAGIC
# MAGIC This structured approach enables systematic evaluation while maintaining full observability into individual agent interactions.

# COMMAND ----------

# MAGIC %md
# MAGIC ### B4. MLflow Tracing: The Foundation of Agent Observability
# MAGIC
# MAGIC MLflow Tracing provides comprehensive observability into agent execution, capturing every step of your agent's reasoning process. Tracing is enabled when using `mlflow.genai.evaluate()` with properly instrumented predict functions and forms the foundation for many evaluation capabilities.
# MAGIC
# MAGIC **What tracing captures:**
# MAGIC
# MAGIC - **Model calls**: Every interaction with foundation models, including prompts, responses, and model parameters
# MAGIC - **Tool invocations**: Function calls with input parameters and return values
# MAGIC - **Retrieval operations**: Documents retrieved from vector stores, with content and metadata
# MAGIC - **Timing information**: Duration of each operation for performance analysis
# MAGIC - **Hierarchical structure**: Parent-child relationships showing the execution flow

# COMMAND ----------

# MAGIC %md
# MAGIC ### B5. Span Types in Traces
# MAGIC
# MAGIC MLflow organizes traces into spans with specific types:
# MAGIC - **Root span**: Top-level span representing the complete agent invocation
# MAGIC - **RETRIEVER**: Spans where documents are fetched from vector search or other retrieval systems
# MAGIC - **TOOL**: Individual tool or function calls
# MAGIC - **CHAT_MODEL**: Language model interactions
# MAGIC - **CHAIN**: Sequences of operations (common in LangChain-based agents)
# MAGIC
# MAGIC **Why tracing matters for evaluation:**
# MAGIC
# MAGIC Certain evaluation judges, like `RetrievalSufficiency`, require traces to function. They analyze what was retrieved (not just the final response) to assess whether the retrieval system provided adequate information. Without traces, these sophisticated evaluations would be impossible.
# MAGIC
# MAGIC Tracing also enables debugging by allowing you to inspect exactly what happened during a failed evaluation, identifying whether issues stem from retrieval quality, tool selection, or LLM reasoning.

# COMMAND ----------

# MAGIC %md
# MAGIC ### B6. AI Gateway Integration and Inference Tables
# MAGIC
# MAGIC When you register agents using the Mosaic AI Agent Framework and deploy them to Model Serving, Databricks automatically enables AI Gateway-enhanced inference tables. These tables provide detailed logging of all requests and responses in production.
# MAGIC
# MAGIC **Inference table benefits:**
# MAGIC
# MAGIC - **Automatic logging**: Every request to your deployed agent is captured without additional instrumentation
# MAGIC - **Rich metadata**: Includes request/response content, timestamps, latency, model versions, and trace data
# MAGIC - **Query interface**: SQL-queryable tables in Unity Catalog for analysis and monitoring
# MAGIC - **Evaluation integration**: Inference table data can be directly used as evaluation datasets

# COMMAND ----------

# MAGIC %md
# MAGIC ### B7. From Production to Evaluation
# MAGIC
# MAGIC This integration creates a powerful feedback loop:
# MAGIC 1. Agents run in production and log all interactions to inference tables
# MAGIC 2. You query inference tables to extract interesting examples, failure cases, or edge cases
# MAGIC 3. These real-world examples augment your evaluation dataset
# MAGIC 4. Future evaluations test against actual production scenarios
# MAGIC
# MAGIC This approach ensures your evaluation dataset evolves with real user behavior rather than remaining static and potentially stale.

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Types of Evaluation Judges

# COMMAND ----------

# MAGIC %md
# MAGIC | Approach              | Level of customization | Use cases |
# MAGIC |----------------------|------------------------|-----------|
# MAGIC | Built-in judges      | Minimal                | Quickly try LLM evaluation with built-in scorers such as `Correctness` and `RetrievalGroundedness`. |
# MAGIC | Guidelines judges    | Moderate               | A built-in judge that checks whether responses pass or fail custom natural-language rules, such as style or factuality guidelines. |
# MAGIC | Custom judges        | Full                   | Create fully customized LLM judges with detailed evaluation criteria and feedback optimization. Capable of returning numerical scores, categories, or boolean values. |
# MAGIC | Code-based scorers   | Full                   | Programmatic and deterministic scorers that evaluate things like exact matching, format validation, and performance metrics. |

# COMMAND ----------

# MAGIC %md
# MAGIC ### C1. Built-In Judges for Common Criteria
# MAGIC
# MAGIC MLflow provides research-validated judges for common evaluation tasks. These judges have been developed through extensive research, validated against human expert judgment, and optimized for specific evaluation criteria.

# COMMAND ----------

# MAGIC %md
# MAGIC ### C2. Core Built-in Judges Include:
# MAGIC
# MAGIC - **Correctness**  
# MAGIC Evaluates whether the model's response is factually correct compared to provided ground truth.  
# MAGIC Requires ground truth in the evaluation dataset via `expectations` (for example, an expected answer or expected facts).
# MAGIC
# MAGIC - **RelevanceToQuery**  
# MAGIC Assesses whether the response directly and appropriately addresses the user's query.  
# MAGIC Useful for identifying off-topic, tangential, or irrelevant answers. Does **not** require ground truth.
# MAGIC
# MAGIC - **RetrievalSufficiency**  
# MAGIC Determines whether the retrieved context contains all the information necessary to produce a correct response that includes the ground-truth facts.  
# MAGIC Requires ground truth (`expectations`) and evaluates retrieval quality rather than generation quality.
# MAGIC
# MAGIC - **RetrievalRelevance**  
# MAGIC Evaluates whether the retrieved documents are relevant to the user's query.  
# MAGIC Does **not** require ground truth and focuses only on the retrieval step, independent of the final answer.

# COMMAND ----------

# MAGIC %md
# MAGIC ### C3. Additional Built-in Judges:
# MAGIC
# MAGIC - **RetrievalGroundedness**  
# MAGIC Checks whether the model's response is grounded in the retrieved context and does not hallucinate unsupported facts.  
# MAGIC Does **not** require ground truth and evaluates alignment between the response and provided documents.
# MAGIC
# MAGIC - **Safety**  
# MAGIC Assesses whether the response is free from harmful, offensive, or unsafe content.  
# MAGIC Does **not** require ground truth and is commonly used as a baseline content safety check.
# MAGIC
# MAGIC - **Guidelines**  
# MAGIC Evaluates whether the response follows specified natural-language rules or constraints (for example, style, tone, or formatting requirements).  
# MAGIC Does **not** require ground truth.
# MAGIC
# MAGIC - **ExpectationsGuidelines**  
# MAGIC Evaluates whether the response meets per-example natural-language criteria defined in the evaluation dataset.  
# MAGIC Does not require factual ground truth, but relies on example-specific guidelines provided in `expectations`.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C4. Example Usage Pattern
# MAGIC
# MAGIC <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
# MAGIC   <colgroup>
# MAGIC     <col style="width: 60%;">
# MAGIC     <col style="width: 40%;">
# MAGIC   </colgroup>
# MAGIC   <tr>
# MAGIC     <td style="vertical-align: top; padding-right: 20px;">
# MAGIC       <div class="code-block-dark" data-language="python">
# MAGIC from mlflow.genai.scorers import Correctness
# MAGIC
# MAGIC correctness_eval = Correctness(
# MAGIC     model="databricks:/foundation-model-endpoint")
# MAGIC
# MAGIC correctness_results = mlflow.genai.evaluate(
# MAGIC     data=eval_dataset,
# MAGIC     predict_fn=lambda input: agent.predict({"input": input}),
# MAGIC     scorers=[correctness_eval],
# MAGIC )
# MAGIC       </div>
# MAGIC     </td>
# MAGIC     <td style="vertical-align: top; padding-left: 20px; font-size: 16px;">
# MAGIC       <p>This example demonstrates a common pattern for evaluating agents using the <code>Correctness</code> scorer with a Databricks foundation model endpoint.</p>
# MAGIC       <p><strong>For more reading:</strong></p>
# MAGIC       <ul>
# MAGIC         <li><a href="https://docs.databricks.com/aws/en/mlflow3/genai/eval-monitor/concepts/scorers#built-in-llm-judges" target="_blank">Built-in LLM Judges (Databricks)</a></li>
# MAGIC         <li><a href="https://mlflow.org/docs/latest/genai/eval-monitor/scorers/llm-judge/predefined/" target="_blank">Predefined Scorers (MLflow)</a></li>
# MAGIC       </ul>
# MAGIC     </td>
# MAGIC   </tr>
# MAGIC </table>
# MAGIC
# MAGIC <style id="prism-inline-css">
# MAGIC /* Prism Tomorrow Night theme - inlined */
# MAGIC code[class*="language-"],pre[class*="language-"]{color:#ccc;background:0 0;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;font-size:1em;text-align:left;white-space:pre;word-spacing:normal;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}pre[class*="language-"]{padding:1em;margin:.5em 0;overflow:auto}:not(pre)>code[class*="language-"],pre[class*="language-"]{background:#2d2d2d}:not(pre)>code[class*="language-"]{padding:.1em;border-radius:.3em;white-space:normal}.token.comment,.token.block-comment,.token.prolog,.token.doctype,.token.cdata{color:#999}.token.punctuation{color:#ccc}.token.tag,.token.attr-name,.token.namespace,.token.deleted{color:#e2777a}.token.function-name{color:#6196cc}.token.boolean,.token.number,.token.function{color:#f08d49}.token.property,.token.class-name,.token.constant,.token.symbol{color:#f8c555}.token.selector,.token.important,.token.atrule,.token.keyword,.token.builtin{color:#cc99cd}.token.string,.token.char,.token.attr-value,.token.regex,.token.variable{color:#7ec699}.token.operator,.token.entity,.token.url{color:#67cdcc}.token.important,.token.bold{font-weight:700}.token.italic{font-style:italic}.token.entity{cursor:help}.token.inserted{color:green}
# MAGIC </style>
# MAGIC
# MAGIC <script>
# MAGIC // Minimal Prism core + Python/SQL - inlined (no external requests)
# MAGIC (function(){
# MAGIC var Prism = window.Prism = {
# MAGIC     languages: {},
# MAGIC     highlight: function(text, grammar) {
# MAGIC         return this.tokenize(text, grammar).map(function(token) {
# MAGIC             if (typeof token === 'string') return token;
# MAGIC             var type = token.type, content = token.content;
# MAGIC             return '<span class="token ' + type + '">' + content + '</span>';
# MAGIC         }).join('');
# MAGIC     },
# MAGIC     tokenize: function(text, grammar) {
# MAGIC         var tokens = [text];
# MAGIC         for (var key in grammar) {
# MAGIC             var pattern = grammar[key];
# MAGIC             for (var i = 0; i < tokens.length; i++) {
# MAGIC                 if (typeof tokens[i] !== 'string') continue;
# MAGIC                 var match, matches = [];
# MAGIC                 pattern.lastIndex = 0;
# MAGIC                 while ((match = pattern.exec(tokens[i])) !== null) {
# MAGIC                     matches.push({index: match.index, length: match[0].length, value: match[0]});
# MAGIC                 }
# MAGIC                 if (!matches.length) continue;
# MAGIC                 var newTokens = [];
# MAGIC                 var lastIndex = 0;
# MAGIC                 matches.forEach(function(m) {
# MAGIC                     if (m.index > lastIndex) newTokens.push(tokens[i].substring(lastIndex, m.index));
# MAGIC                     newTokens.push({type: key, content: m.value});
# MAGIC                     lastIndex = m.index + m.length;
# MAGIC                 });
# MAGIC                 if (lastIndex < tokens[i].length) newTokens.push(tokens[i].substring(lastIndex));
# MAGIC                 tokens.splice.apply(tokens, [i, 1].concat(newTokens));
# MAGIC             }
# MAGIC         }
# MAGIC         return tokens;
# MAGIC     },
# MAGIC     highlightElement: function(element) {
# MAGIC         var code = element.textContent;
# MAGIC         var lang = element.className.match(/language-(\w+)/);
# MAGIC         lang = lang ? lang[1] : 'python';
# MAGIC         var grammar = this.languages[lang] || this.languages.python;
# MAGIC         element.innerHTML = this.highlight(code, grammar);
# MAGIC     }
# MAGIC };
# MAGIC
# MAGIC // Python grammar
# MAGIC Prism.languages.python = {
# MAGIC     'comment': /#.*/g,
# MAGIC     'string': /("""[\s\S]*?"""|'''[\s\S]*?'''|"[^"]*"|'[^']*')/g,
# MAGIC     'keyword': /\b(import|from|def|class|return|if|elif|else|for|while|try|except|finally|with|as|pass|break|continue|yield|lambda|async|await|None|True|False)\b/g,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[-+*/%=<>!&|^~]+/g,
# MAGIC     'punctuation': /[{}[\];(),.]/g
# MAGIC };
# MAGIC
# MAGIC // SQL grammar
# MAGIC Prism.languages.sql = {
# MAGIC     'comment': /--.*|\/\*[\s\S]*?\*\//g,
# MAGIC     'string': /'[^']*'/g,
# MAGIC     'keyword': /\b(SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|GRANT|TABLE|CATALOG|TO|ON|LIMIT|AND|OR|NOT|IN|AS|IS|NULL|JOIN|LEFT|RIGHT|INNER|OUTER|GROUP|BY|ORDER|HAVING|DISTINCT|COUNT|SUM|AVG|MAX|MIN)\b/gi,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[<>!=]=?|[-+*/%]|\b(LIKE|BETWEEN)\b/gi,
# MAGIC     'punctuation': /[;,.()]/g
# MAGIC };
# MAGIC
# MAGIC // Auto-process code blocks
# MAGIC document.querySelectorAll('.code-block-dark').forEach(function(block) {
# MAGIC     if (block.getAttribute('data-processed')) return;
# MAGIC     block.setAttribute('data-processed', 'true');
# MAGIC     var lang = block.getAttribute('data-language') || 'python';
# MAGIC     var code = block.textContent.trim();
# MAGIC     var id = 'code-dark-' + Math.random().toString(36).substr(2, 9);
# MAGIC     block.innerHTML = 
# MAGIC         '<div style="position:relative;margin:16px 0;max-width:100%;">' +
# MAGIC             '<button class="copy-btn" style="position:absolute;top:8px;right:8px;padding:4px 12px;font-size:12px;background:#555;color:#fff;border:1px solid #666;border-radius:4px;cursor:pointer;z-index:10;">Copy</button>' +
# MAGIC             '<pre style="background:#2d2d2d;border-radius:8px;padding:16px;padding-top:40px;overflow-x:auto;margin:0;border:1px solid #444;max-width:100%;box-sizing:border-box;"><code id="' + id + '" class="language-' + lang + '" style="font-family:Consolas,Monaco,monospace;font-size:13px;word-wrap:break-word;white-space:pre-wrap;"></code></pre>' +
# MAGIC         '</div>';
# MAGIC     var codeEl = document.getElementById(id);
# MAGIC     codeEl.textContent = code;
# MAGIC     Prism.highlightElement(codeEl);
# MAGIC     block.querySelector('.copy-btn').onclick = function() {
# MAGIC         var t = document.createElement('textarea');
# MAGIC         t.value = code;
# MAGIC         document.body.appendChild(t);
# MAGIC         t.select();
# MAGIC         document.execCommand('copy');
# MAGIC         document.body.removeChild(t);
# MAGIC         this.textContent = '✓ Copied!';
# MAGIC         setTimeout(() => this.textContent = 'Copy', 2000);
# MAGIC     };
# MAGIC });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## ⚠️ Demo Checkpoint
# MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC     <span style="font-size: 24px;"></span>
# MAGIC     <div>
# MAGIC       <strong style="color: #e65100; font-size: 1.1em;">Demo Checkpoint</strong>
# MAGIC       <p style="margin: 8px 0 0 0; color: #333;">Navigate to <strong>02 Demo - Using MLflow Built-In Judges</strong> to see these built-in judges in action. When you are finished, navigate back to this lecture notebook and continue learning.</p>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C5. Two Types of Guideline Judges:
# MAGIC
# MAGIC <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
# MAGIC   <colgroup>
# MAGIC     <col style="width: 60%;">
# MAGIC     <col style="width: 40%;">
# MAGIC   </colgroup>
# MAGIC   <tr>
# MAGIC     <td style="vertical-align: top; padding-right: 20px;">
# MAGIC       <div class="code-block-dark" data-language="python">
# MAGIC from mlflow.genai.scorers import Guidelines
# MAGIC
# MAGIC tone_guidelines = Guidelines(
# MAGIC     name="professional_tone",
# MAGIC     guidelines=[
# MAGIC         "The response must use professional, business-appropriate language",
# MAGIC         "The response should avoid slang, colloquialisms, or overly casual phrasing",
# MAGIC         "The response must address the user respectfully"
# MAGIC     ],
# MAGIC     model="databricks:/foundation-model-endpoint"
# MAGIC )
# MAGIC       </div>
# MAGIC     </td>
# MAGIC     <td style="vertical-align: top; padding-left: 20px; font-size: 16px;">
# MAGIC       <p><strong>1. Global Guidelines (<code>Guidelines</code> class)</strong></p>
# MAGIC       <p>Apply uniform criteria to all evaluations in your dataset. Global guidelines are ideal when you want to enforce consistent standards across all test cases, such as tone, style, or formatting requirements.</p>
# MAGIC       <p>The example shows how to create guidelines that ensure professional communication tone across all agent responses.</p>
# MAGIC     </td>
# MAGIC   </tr>
# MAGIC </table>
# MAGIC
# MAGIC <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
# MAGIC   <colgroup>
# MAGIC     <col style="width: 60%;">
# MAGIC     <col style="width: 40%;">
# MAGIC   </colgroup>
# MAGIC   <tr>
# MAGIC     <td style="vertical-align: top; padding-right: 20px;">
# MAGIC       <div class="code-block-dark" data-language="python">
# MAGIC from mlflow.genai.scorers import ExpectationsGuidelines
# MAGIC
# MAGIC &#35; Dataset contains per-row guidelines in expectations
# MAGIC &#35; Example row:
# MAGIC &#35; {
# MAGIC &#35;   "input": "What's the refund policy?",
# MAGIC &#35;   "output": "Our refund policy allows...",
# MAGIC &#35;   "expectations": {
# MAGIC &#35;     "guidelines": ["Must mention 30-day timeframe", "Must include receipt requirement"]
# MAGIC &#35;   }
# MAGIC &#35; }
# MAGIC
# MAGIC expected_guidelines = ExpectationsGuidelines(
# MAGIC     name="policy_requirements",
# MAGIC     model="databricks:/foundation-model-endpoint"
# MAGIC )
# MAGIC       </div>
# MAGIC     </td>
# MAGIC     <td style="vertical-align: top; padding-left: 20px; font-size: 16px;">
# MAGIC       <p><strong>2. Per-Row Guidelines (<code>ExpectationsGuidelines</code> class)</strong></p>
# MAGIC       <p>Apply different criteria to each example, useful when different scenarios require different standards. Each row in your dataset includes its own specific guidelines in an <code>expectations</code> field.</p>
# MAGIC       <p>This approach is ideal for testing diverse use cases where each input requires unique validation criteria.</p>
# MAGIC     </td>
# MAGIC   </tr>
# MAGIC </table>
# MAGIC
# MAGIC <style id="prism-inline-css">
# MAGIC /* Prism Tomorrow Night theme - inlined */
# MAGIC code[class*="language-"],pre[class*="language-"]{color:#ccc;background:0 0;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;font-size:1em;text-align:left;white-space:pre;word-spacing:normal;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}pre[class*="language-"]{padding:1em;margin:.5em 0;overflow:auto}:not(pre)>code[class*="language-"],pre[class*="language-"]{background:#2d2d2d}:not(pre)>code[class*="language-"]{padding:.1em;border-radius:.3em;white-space:normal}.token.comment,.token.block-comment,.token.prolog,.token.doctype,.token.cdata{color:#999}.token.punctuation{color:#ccc}.token.tag,.token.attr-name,.token.namespace,.token.deleted{color:#e2777a}.token.function-name{color:#6196cc}.token.boolean,.token.number,.token.function{color:#f08d49}.token.property,.token.class-name,.token.constant,.token.symbol{color:#f8c555}.token.selector,.token.important,.token.atrule,.token.keyword,.token.builtin{color:#cc99cd}.token.string,.token.char,.token.attr-value,.token.regex,.token.variable{color:#7ec699}.token.operator,.token.entity,.token.url{color:#67cdcc}.token.important,.token.bold{font-weight:700}.token.italic{font-style:italic}.token.entity{cursor:help}.token.inserted{color:green}
# MAGIC </style>
# MAGIC
# MAGIC <script>
# MAGIC // Minimal Prism core + Python/SQL - inlined (no external requests)
# MAGIC (function(){
# MAGIC function escapeHtml(text) {
# MAGIC     var div = document.createElement('div');
# MAGIC     div.textContent = text;
# MAGIC     return div.innerHTML;
# MAGIC }
# MAGIC
# MAGIC var Prism = window.Prism = {
# MAGIC     languages: {},
# MAGIC     highlight: function(text, grammar) {
# MAGIC         return this.tokenize(text, grammar).map(function(token) {
# MAGIC             if (typeof token === 'string') return escapeHtml(token);
# MAGIC             var type = token.type, content = token.content;
# MAGIC             return '<span class="token ' + type + '">' + escapeHtml(content) + '</span>';
# MAGIC         }).join('');
# MAGIC     },
# MAGIC     tokenize: function(text, grammar) {
# MAGIC         var tokens = [text];
# MAGIC         for (var key in grammar) {
# MAGIC             var pattern = grammar[key];
# MAGIC             for (var i = 0; i < tokens.length; i++) {
# MAGIC                 if (typeof tokens[i] !== 'string') continue;
# MAGIC                 var match, matches = [];
# MAGIC                 pattern.lastIndex = 0;
# MAGIC                 while ((match = pattern.exec(tokens[i])) !== null) {
# MAGIC                     matches.push({index: match.index, length: match[0].length, value: match[0]});
# MAGIC                 }
# MAGIC                 if (!matches.length) continue;
# MAGIC                 var newTokens = [];
# MAGIC                 var lastIndex = 0;
# MAGIC                 matches.forEach(function(m) {
# MAGIC                     if (m.index > lastIndex) newTokens.push(tokens[i].substring(lastIndex, m.index));
# MAGIC                     newTokens.push({type: key, content: m.value});
# MAGIC                     lastIndex = m.index + m.length;
# MAGIC                 });
# MAGIC                 if (lastIndex < tokens[i].length) newTokens.push(tokens[i].substring(lastIndex));
# MAGIC                 tokens.splice.apply(tokens, [i, 1].concat(newTokens));
# MAGIC             }
# MAGIC         }
# MAGIC         return tokens;
# MAGIC     },
# MAGIC     highlightElement: function(element) {
# MAGIC         var code = element.textContent;
# MAGIC         var lang = element.className.match(/language-(\w+)/);
# MAGIC         lang = lang ? lang[1] : 'python';
# MAGIC         var grammar = this.languages[lang] || this.languages.python;
# MAGIC         element.innerHTML = this.highlight(code, grammar);
# MAGIC     }
# MAGIC };
# MAGIC
# MAGIC // Python grammar
# MAGIC Prism.languages.python = {
# MAGIC     'comment': /#.*/g,
# MAGIC     'string': /("""[\s\S]*?"""|'''[\s\S]*?'''|"[^"]*"|'[^']*')/g,
# MAGIC     'keyword': /\b(import|from|def|class|return|if|elif|else|for|while|try|except|finally|with|as|pass|break|continue|yield|lambda|async|await|None|True|False)\b/g,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[-+*/%=<>!&|^~]+/g,
# MAGIC     'punctuation': /[{}[\];(),.]/g
# MAGIC };
# MAGIC
# MAGIC // SQL grammar
# MAGIC Prism.languages.sql = {
# MAGIC     'comment': /--.*|\/\*[\s\S]*?\*\//g,
# MAGIC     'string': /'[^']*'/g,
# MAGIC     'keyword': /\b(SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|GRANT|TABLE|CATALOG|TO|ON|LIMIT|AND|OR|NOT|IN|AS|IS|NULL|JOIN|LEFT|RIGHT|INNER|OUTER|GROUP|BY|ORDER|HAVING|DISTINCT|COUNT|SUM|AVG|MAX|MIN)\b/gi,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[<>!=]=?|[-+*/%]|\b(LIKE|BETWEEN)\b/gi,
# MAGIC     'punctuation': /[;,.()]/g
# MAGIC };
# MAGIC
# MAGIC // Auto-process code blocks
# MAGIC document.querySelectorAll('.code-block-dark').forEach(function(block) {
# MAGIC     if (block.getAttribute('data-processed')) return;
# MAGIC     block.setAttribute('data-processed', 'true');
# MAGIC     var lang = block.getAttribute('data-language') || 'python';
# MAGIC     var code = block.textContent.trim();
# MAGIC     var id = 'code-dark-' + Math.random().toString(36).substr(2, 9);
# MAGIC     block.innerHTML = 
# MAGIC         '<div style="position:relative;margin:16px 0;max-width:100%;">' +
# MAGIC             '<button class="copy-btn" style="position:absolute;top:8px;right:8px;padding:4px 12px;font-size:12px;background:#555;color:#fff;border:1px solid #666;border-radius:4px;cursor:pointer;z-index:10;">Copy</button>' +
# MAGIC             '<pre style="background:#2d2d2d;border-radius:8px;padding:16px;padding-top:40px;overflow-x:auto;margin:0;border:1px solid #444;max-width:100%;box-sizing:border-box;"><code id="' + id + '" class="language-' + lang + '" style="font-family:Consolas,Monaco,monospace;font-size:13px;word-wrap:break-word;white-space:pre-wrap;"></code></pre>' +
# MAGIC         '</div>';
# MAGIC     var codeEl = document.getElementById(id);
# MAGIC     codeEl.textContent = code;
# MAGIC     Prism.highlightElement(codeEl);
# MAGIC     block.querySelector('.copy-btn').onclick = function() {
# MAGIC         var t = document.createElement('textarea');
# MAGIC         t.value = code;
# MAGIC         document.body.appendChild(t);
# MAGIC         t.select();
# MAGIC         document.execCommand('copy');
# MAGIC         document.body.removeChild(t);
# MAGIC         this.textContent = '✓ Copied!';
# MAGIC         var btn = this;
# MAGIC         setTimeout(function() { btn.textContent = 'Copy'; }, 2000);
# MAGIC     };
# MAGIC });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### C6. Guideline Judge Advantages and Best Practices
# MAGIC
# MAGIC **Guideline judge advantages:**
# MAGIC
# MAGIC - **Domain expert accessibility**: Business stakeholders can write guidelines without coding
# MAGIC - **Rapid iteration**: Update evaluation criteria without code changes
# MAGIC - **Interpretability**: Natural language guidelines are self-documenting
# MAGIC - **Flexibility**: Express complex, context-dependent requirements that would be difficult to code
# MAGIC
# MAGIC **Tips for writing guidelines:**
# MAGIC
# MAGIC - Be specific and concrete rather than vague ("Response must cite the source document" vs. "Response should be credible")
# MAGIC - Write guidelines that can be objectively verified
# MAGIC - Focus on observable attributes in the response
# MAGIC - Test guidelines on multiple examples to ensure they work as intended

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## ⚠️ Demo Checkpoint
# MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC     <span style="font-size: 24px;"></span>
# MAGIC     <div>
# MAGIC       <strong style="color: #e65100; font-size: 1.1em;">Demo Checkpoint</strong>
# MAGIC       <p style="margin: 8px 0 0 0; color: #333;">Navigate to <strong>03 Demo - Guideline Judges with MLflow</strong> to explore guideline judges in practice. When you are finished, navigate back to this lecture notebook and continue learning.</p>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## ⚠️ Lab Checkpoint
# MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC     <span style="font-size: 24px;"></span>
# MAGIC     <div>
# MAGIC       <strong style="color: #e65100; font-size: 1.1em;">Lab Checkpoint</strong>
# MAGIC       <p style="margin: 8px 0 0 0; color: #333;">Navigate to <strong>04 Lab - Applying Agent Evaluation</strong> to practice implementing comprehensive evaluation workflows. When you are finished, navigate back to this lecture notebook and continue learning.</p>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### C7. Custom Judges and Code-Based Scorers
# MAGIC
# MAGIC When built-in judges don't meet your needs, MLflow supports custom evaluation logic through two approaches:
# MAGIC
# MAGIC <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
# MAGIC   <colgroup>
# MAGIC     <col style="width: 60%;">
# MAGIC     <col style="width: 40%;">
# MAGIC   </colgroup>
# MAGIC   <tr>
# MAGIC     <td style="vertical-align: top; padding-right: 20px;">
# MAGIC       <div class="code-block-dark" data-language="python">
# MAGIC from mlflow.genai.scorers import scorer
# MAGIC from mlflow.entities import Feedback
# MAGIC
# MAGIC @scorer
# MAGIC def response_length(outputs):
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;"""Verify response length is appropriate."""
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;word_count = len(str(outputs.get("response", "")).split())
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;if 20 &lt;= word_count &lt;= 100:
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return Feedback(
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;value="yes",
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;rationale=f"Response length ({word_count} words) is appropriate"
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;else:
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;return Feedback(
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;value="no",
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;rationale=f"Response is too {'short' if word_count &lt; 20 else 'long'} ({word_count} words)"
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;)
# MAGIC       </div>
# MAGIC     </td>
# MAGIC     <td style="vertical-align: top; padding-left: 20px; font-size: 16px;">
# MAGIC       <p><strong>Code-based scorers for deterministic evaluation</strong></p>
# MAGIC       <p>Custom scorers allow you to implement domain-specific validation logic that goes beyond what built-in judges provide. The <code>@scorer</code> decorator converts your function into a reusable evaluation component.</p>
# MAGIC       <p>This example shows how to validate response length and provide detailed feedback with rationale for why a response passed or failed the check.</p>
# MAGIC     </td>
# MAGIC   </tr>
# MAGIC </table>
# MAGIC
# MAGIC **Alternative approach with primitive return:**
# MAGIC
# MAGIC <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
# MAGIC   <colgroup>
# MAGIC     <col style="width: 60%;">
# MAGIC     <col style="width: 40%;">
# MAGIC   </colgroup>
# MAGIC   <tr>
# MAGIC     <td style="vertical-align: top; padding-right: 20px;">
# MAGIC       <div class="code-block-dark" data-language="python">
# MAGIC from mlflow.genai.scorers import scorer
# MAGIC
# MAGIC @scorer
# MAGIC def response_length(outputs):
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;wc = len(str(outputs.get("response", "")).split())
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;return "yes" if 20 &lt;= wc &lt;= 100 else "no"
# MAGIC       </div>
# MAGIC     </td>
# MAGIC     <td style="vertical-align: top; padding-left: 20px; font-size: 16px;">
# MAGIC       <p>For simpler use cases, scorers can return primitive values directly (strings, booleans, or numbers) without creating a <code>Feedback</code> object.</p>
# MAGIC       <p>This approach is more concise but doesn't provide rationale for the scoring decision, making it better suited for straightforward pass/fail checks.</p>
# MAGIC     </td>
# MAGIC   </tr>
# MAGIC </table>
# MAGIC
# MAGIC <style id="prism-inline-css">
# MAGIC /* Prism Tomorrow Night theme - inlined */
# MAGIC code[class*="language-"],pre[class*="language-"]{color:#ccc;background:0 0;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;font-size:1em;text-align:left;white-space:pre;word-spacing:normal;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}pre[class*="language-"]{padding:1em;margin:.5em 0;overflow:auto}:not(pre)>code[class*="language-"],pre[class*="language-"]{background:#2d2d2d}:not(pre)>code[class*="language-"]{padding:.1em;border-radius:.3em;white-space:normal}.token.comment,.token.block-comment,.token.prolog,.token.doctype,.token.cdata{color:#999}.token.punctuation{color:#ccc}.token.tag,.token.attr-name,.token.namespace,.token.deleted{color:#e2777a}.token.function-name{color:#6196cc}.token.boolean,.token.number,.token.function{color:#f08d49}.token.property,.token.class-name,.token.constant,.token.symbol{color:#f8c555}.token.selector,.token.important,.token.atrule,.token.keyword,.token.builtin{color:#cc99cd}.token.string,.token.char,.token.attr-value,.token.regex,.token.variable{color:#7ec699}.token.operator,.token.entity,.token.url{color:#67cdcc}.token.important,.token.bold{font-weight:700}.token.italic{font-style:italic}.token.entity{cursor:help}.token.inserted{color:green}
# MAGIC </style>
# MAGIC
# MAGIC <script>
# MAGIC // Minimal Prism core + Python/SQL - inlined (no external requests)
# MAGIC (function(){
# MAGIC function escapeHtml(text) {
# MAGIC     var div = document.createElement('div');
# MAGIC     div.textContent = text;
# MAGIC     return div.innerHTML;
# MAGIC }
# MAGIC
# MAGIC var Prism = window.Prism = {
# MAGIC     languages: {},
# MAGIC     highlight: function(text, grammar) {
# MAGIC         return this.tokenize(text, grammar).map(function(token) {
# MAGIC             if (typeof token === 'string') return escapeHtml(token);
# MAGIC             var type = token.type, content = token.content;
# MAGIC             return '<span class="token ' + type + '">' + escapeHtml(content) + '</span>';
# MAGIC         }).join('');
# MAGIC     },
# MAGIC     tokenize: function(text, grammar) {
# MAGIC         var tokens = [text];
# MAGIC         for (var key in grammar) {
# MAGIC             var pattern = grammar[key];
# MAGIC             for (var i = 0; i < tokens.length; i++) {
# MAGIC                 if (typeof tokens[i] !== 'string') continue;
# MAGIC                 var match, matches = [];
# MAGIC                 pattern.lastIndex = 0;
# MAGIC                 while ((match = pattern.exec(tokens[i])) !== null) {
# MAGIC                     matches.push({index: match.index, length: match[0].length, value: match[0]});
# MAGIC                 }
# MAGIC                 if (!matches.length) continue;
# MAGIC                 var newTokens = [];
# MAGIC                 var lastIndex = 0;
# MAGIC                 matches.forEach(function(m) {
# MAGIC                     if (m.index > lastIndex) newTokens.push(tokens[i].substring(lastIndex, m.index));
# MAGIC                     newTokens.push({type: key, content: m.value});
# MAGIC                     lastIndex = m.index + m.length;
# MAGIC                 });
# MAGIC                 if (lastIndex < tokens[i].length) newTokens.push(tokens[i].substring(lastIndex));
# MAGIC                 tokens.splice.apply(tokens, [i, 1].concat(newTokens));
# MAGIC             }
# MAGIC         }
# MAGIC         return tokens;
# MAGIC     },
# MAGIC     highlightElement: function(element) {
# MAGIC         var code = element.textContent;
# MAGIC         var lang = element.className.match(/language-(\w+)/);
# MAGIC         lang = lang ? lang[1] : 'python';
# MAGIC         var grammar = this.languages[lang] || this.languages.python;
# MAGIC         element.innerHTML = this.highlight(code, grammar);
# MAGIC     }
# MAGIC };
# MAGIC
# MAGIC // Python grammar
# MAGIC Prism.languages.python = {
# MAGIC     'comment': /#.*/g,
# MAGIC     'string': /("""[\s\S]*?"""|'''[\s\S]*?'''|"[^"]*"|'[^']*')/g,
# MAGIC     'keyword': /\b(import|from|def|class|return|if|elif|else|for|while|try|except|finally|with|as|pass|break|continue|yield|lambda|async|await|None|True|False)\b/g,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[-+*/%=<>!&|^~]+/g,
# MAGIC     'punctuation': /[{}[\];(),.]/g
# MAGIC };
# MAGIC
# MAGIC // SQL grammar
# MAGIC Prism.languages.sql = {
# MAGIC     'comment': /--.*|\/\*[\s\S]*?\*\//g,
# MAGIC     'string': /'[^']*'/g,
# MAGIC     'keyword': /\b(SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|GRANT|TABLE|CATALOG|TO|ON|LIMIT|AND|OR|NOT|IN|AS|IS|NULL|JOIN|LEFT|RIGHT|INNER|OUTER|GROUP|BY|ORDER|HAVING|DISTINCT|COUNT|SUM|AVG|MAX|MIN)\b/gi,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[<>!=]=?|[-+*/%]|\b(LIKE|BETWEEN)\b/gi,
# MAGIC     'punctuation': /[;,.()]/g
# MAGIC };
# MAGIC
# MAGIC // Auto-process code blocks
# MAGIC document.querySelectorAll('.code-block-dark').forEach(function(block) {
# MAGIC     if (block.getAttribute('data-processed')) return;
# MAGIC     block.setAttribute('data-processed', 'true');
# MAGIC     var lang = block.getAttribute('data-language') || 'python';
# MAGIC     var code = block.textContent.trim();
# MAGIC     var id = 'code-dark-' + Math.random().toString(36).substr(2, 9);
# MAGIC     block.innerHTML = 
# MAGIC         '<div style="position:relative;margin:16px 0;max-width:100%;">' +
# MAGIC             '<button class="copy-btn" style="position:absolute;top:8px;right:8px;padding:4px 12px;font-size:12px;background:#555;color:#fff;border:1px solid #666;border-radius:4px;cursor:pointer;z-index:10;">Copy</button>' +
# MAGIC             '<pre style="background:#2d2d2d;border-radius:8px;padding:16px;padding-top:40px;overflow-x:auto;margin:0;border:1px solid #444;max-width:100%;box-sizing:border-box;white-space:pre;"><code id="' + id + '" class="language-' + lang + '" style="font-family:Consolas,Monaco,monospace;font-size:13px;"></code></pre>' +
# MAGIC         '</div>';
# MAGIC     var codeEl = document.getElementById(id);
# MAGIC     codeEl.textContent = code;
# MAGIC     Prism.highlightElement(codeEl);
# MAGIC     block.querySelector('.copy-btn').onclick = function() {
# MAGIC         var t = document.createElement('textarea');
# MAGIC         t.value = code;
# MAGIC         document.body.appendChild(t);
# MAGIC         t.select();
# MAGIC         document.execCommand('copy');
# MAGIC         document.body.removeChild(t);
# MAGIC         this.textContent = '✓ Copied!';
# MAGIC         var btn = this;
# MAGIC         setTimeout(function() { btn.textContent = 'Copy'; }, 2000);
# MAGIC     };
# MAGIC });
# MAGIC })();
# MAGIC </script>
# MAGIC
# MAGIC `@scorer` turns your plain Python function into an MLflow GenAI Scorer, which is a first-class, pluggable metric that m`lflow.genai.evaluate()` can run offline and that you can register for production monitoring later. It handles data plumbing, output normalization, and metric naming for you.

# COMMAND ----------

# MAGIC %md
# MAGIC ### C8. Custom LLM Judges
# MAGIC
# MAGIC **Custom LLM judges** for sophisticated evaluation:
# MAGIC
# MAGIC You can implement your own LLM-based judges for specialized evaluation criteria not covered by built-in judges. This involves:
# MAGIC 1. Designing evaluation prompts that clearly specify your criteria
# MAGIC 2. Calling an LLM to make judgments based on those prompts
# MAGIC 3. Parsing LLM responses into structured `Feedback` objects
# MAGIC 4. Wrapping this logic in a function compatible with `mlflow.genai.evaluate()`
# MAGIC
# MAGIC **When to use custom judges:**
# MAGIC
# MAGIC - You need domain-specific evaluation criteria unique to your application
# MAGIC - Built-in judges don't capture nuances important to your use case
# MAGIC - You're evaluating against proprietary standards or regulations
# MAGIC - You need evaluation logic that combines multiple signals or data sources
# MAGIC
# MAGIC Custom judges provide maximum flexibility while maintaining integration with MLflow's evaluation framework, tracing, and logging infrastructure.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## ⚠️ Demo Checkpoint
# MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC     <span style="font-size: 24px;"></span>
# MAGIC     <div>
# MAGIC       <strong style="color: #e65100; font-size: 1.1em;">Demo Checkpoint</strong>
# MAGIC       <p style="margin: 8px 0 0 0; color: #333;">Navigate to <strong>05 Demo - Custom Judges with MLflow</strong> to learn how to create custom judges for specialized evaluation needs. When you are finished, navigate back to this lecture notebook and continue learning.</p>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## D. Offline vs. Online Evaluation
# MAGIC
# MAGIC ![offline-vs-online-evaluation.png](./Includes/images/Evaluation with MLflow/offline-vs-online-evaluation.png "offline-vs-online-evaluation.png")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### EXPAND FOR ADDITIONAL NOTES
# MAGIC <details>
# MAGIC
# MAGIC ### Offline Evaluation: Pre-Deployment Validation
# MAGIC
# MAGIC Offline evaluation tests your agent using curated datasets before deployment. This approach provides controlled, reproducible validation of agent quality.
# MAGIC
# MAGIC **Characteristics of offline evaluation:**
# MAGIC
# MAGIC - **Controlled environment**: You control exactly what inputs the agent receives
# MAGIC - **Reproducibility**: Same dataset yields consistent evaluation results (modulo LLM non-determinism)
# MAGIC - **Ground truth availability**: You can include expected outputs, facts, or expert-labeled guidelines
# MAGIC - **Comprehensive coverage**: Intentionally test edge cases, failure modes, and diverse scenarios
# MAGIC - **Pre-deployment gate**: Prevents deploying agents that don't meet quality standards
# MAGIC
# MAGIC ### Offline Evaluation Workflow
# MAGIC
# MAGIC 1. **Dataset creation**: Curate representative examples covering expected use cases, edge cases, and known failure patterns
# MAGIC 2. **Ground truth labeling**: Add expected outputs, facts, or guidelines (often with domain expert involvement)
# MAGIC 3. **Agent execution**: Run your agent on the dataset to generate responses
# MAGIC 4. **Scorer application**: Apply multiple judges to assess various quality dimensions
# MAGIC 5. **Analysis**: Review aggregated metrics and individual failures to identify improvements
# MAGIC 6. **Iteration**: Update agent, re-evaluate, compare results
# MAGIC
# MAGIC **Strengths:**
# MAGIC - Enables rigorous validation before users encounter your agent
# MAGIC - Supports A/B testing different agent configurations
# MAGIC - Provides baseline metrics for production monitoring
# MAGIC
# MAGIC **Limitations:**
# MAGIC - Dataset may not fully represent real user behavior
# MAGIC - Static datasets become stale as usage patterns evolve
# MAGIC - Cannot capture issues that only emerge with scale or diverse users
# MAGIC
# MAGIC ### Online Evaluation: Production Monitoring
# MAGIC
# MAGIC Online evaluation analyzes agent performance using real user interactions in production. This approach captures how your agent performs with actual usage patterns, unexpected inputs, and diverse user populations.
# MAGIC
# MAGIC **Characteristics of online evaluation:**
# MAGIC
# MAGIC - **Real-world data**: Evaluates against actual user queries and behaviors
# MAGIC - **Scale validation**: Tests how your agent handles production load and request diversity
# MAGIC - **Drift detection**: Identifies when performance degrades over time
# MAGIC - **Continuous monitoring**: Ongoing quality signals rather than one-time assessment
# MAGIC - **User feedback integration**: Combines automated evaluation with actual user satisfaction
# MAGIC
# MAGIC ### Online Evaluation Workflow
# MAGIC
# MAGIC 1. **Inference logging**: Deploy agent with AI Gateway-enhanced inference tables enabled
# MAGIC 2. **Automatic tracing**: Every production request creates traces captured in inference tables
# MAGIC 3. **Scheduled evaluation**: Periodically run scorers on recent production traces
# MAGIC 4. **Alert configuration**: Set up monitoring alerts for quality degradation
# MAGIC 5. **Feedback collection**: Gather user thumbs up/down or explicit feedback
# MAGIC 6. **Dataset augmentation**: Extract interesting production examples for offline evaluation
# MAGIC
# MAGIC **MLflow's production monitoring capabilities:**
# MAGIC
# MAGIC Databricks provides built-in production monitoring for agents deployed via Model Serving:
# MAGIC - **Automated scorer execution**: Run MLflow scorers on production traces automatically
# MAGIC - **Quality dashboards**: Visualize evaluation metrics over time
# MAGIC - **Alerting**: Get notified when quality metrics drop below thresholds
# MAGIC - **Trace inspection**: Deep dive into individual failures or edge cases
# MAGIC
# MAGIC ### Strengths and Limitations
# MAGIC
# MAGIC **Strengths:**
# MAGIC - Reflects actual user experience and real-world performance
# MAGIC - Detects issues that weren't anticipated in offline testing
# MAGIC - Provides data for continuous improvement
# MAGIC
# MAGIC **Limitations:**
# MAGIC - Users may experience failures before you detect them
# MAGIC - More difficult to attribute causes (confounding from diverse inputs)
# MAGIC - Requires production infrastructure and monitoring systems
# MAGIC
# MAGIC ### Complementary Strategies
# MAGIC
# MAGIC Effective agent evaluation combines both offline and online approaches:
# MAGIC
# MAGIC **Offline evaluation for:**
# MAGIC - Pre-deployment validation and quality gates
# MAGIC - Comparing alternative agent implementations
# MAGIC - Testing specific hypotheses about agent behavior
# MAGIC - Rapid iteration during development
# MAGIC
# MAGIC **Online evaluation for:**
# MAGIC - Validating that offline results generalize to production
# MAGIC - Detecting performance degradation or drift
# MAGIC - Understanding real user needs and pain points
# MAGIC - Building evaluation datasets from actual usage
# MAGIC
# MAGIC ### Creating a Feedback Loop
# MAGIC
# MAGIC 1. Start with offline evaluation on carefully curated datasets
# MAGIC 2. Deploy to production with monitoring enabled
# MAGIC 3. Analyze production traces to identify failures and edge cases
# MAGIC 4. Add production examples to your offline evaluation dataset
# MAGIC 5. Use enhanced dataset to validate improvements before re-deploying
# MAGIC
# MAGIC This cycle ensures your evaluation evolves with your understanding of real-world usage while maintaining rigorous pre-deployment validation.
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC ## E. Tips for Agent Evaluation
# MAGIC
# MAGIC
# MAGIC ![tips-for-agent-evaluation.png](./Includes/images/Evaluation with MLflow/tips-for-agent-evaluation.png "tips-for-agent-evaluation.png")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### EXPAND FOR ADDITIONAL NOTES
# MAGIC <details>
# MAGIC
# MAGIC ### Building Comprehensive Evaluation Datasets
# MAGIC
# MAGIC The quality of your evaluation depends critically on your dataset. A well-designed evaluation dataset should be representative, diverse, and include appropriate ground truth.
# MAGIC
# MAGIC **Dataset composition principles:**
# MAGIC
# MAGIC **1. Representativeness**: Include examples reflecting typical user queries and use cases
# MAGIC - Analyze production logs or user research to identify common patterns
# MAGIC - Ensure distribution of query types matches expected usage
# MAGIC - Include varying query complexity levels
# MAGIC
# MAGIC **2. Edge case coverage**: Deliberately test boundary conditions and potential failures
# MAGIC - Ambiguous queries that could be interpreted multiple ways
# MAGIC - Queries requiring information not available in retrieval corpus
# MAGIC - Adversarial examples designed to trigger failure modes
# MAGIC - Queries in unexpected formats or phrasings
# MAGIC
# MAGIC **3. Diversity dimensions**: Vary multiple aspects of inputs
# MAGIC - Query length (terse vs. verbose)
# MAGIC - Query complexity (simple fact lookup vs. multi-step reasoning)
# MAGIC - Domain coverage (different topics your agent should handle)
# MAGIC - User expertise levels (novice vs. expert domain knowledge)
# MAGIC
# MAGIC **Ground truth approaches:**
# MAGIC
# MAGIC **Expert labeling**: Domain experts create expected outputs or fact sets
# MAGIC - Most accurate but resource-intensive
# MAGIC - Essential for high-stakes applications
# MAGIC - Creates reusable gold standard dataset
# MAGIC
# MAGIC **Synthetic generation**: Use LLMs to generate expected responses
# MAGIC - Scalable but requires validation
# MAGIC - Useful for bootstrapping evaluation
# MAGIC - Should be spot-checked by humans
# MAGIC
# MAGIC **Production mining**: Extract examples from inference tables
# MAGIC - Reflects real usage patterns
# MAGIC - May require filtering or cleaning
# MAGIC - Can identify emergent failure modes
# MAGIC
# MAGIC **Dataset maintenance:**
# MAGIC
# MAGIC Evaluation datasets require ongoing curation:
# MAGIC - Regularly add new examples from production
# MAGIC - Remove or update stale examples
# MAGIC - Rebalance categories as usage patterns shift
# MAGIC - Version datasets alongside agent versions
# MAGIC </details>

# COMMAND ----------

# MAGIC %md
# MAGIC ## F. MLflow Evaluation Ecosystem
# MAGIC
# MAGIC ![mlflow-ecosystem.png](./Includes/images/Evaluation with MLflow/mlflow-ecosystem.png "mlflow-ecosystem.png")

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ##### EXPAND FOR ADDITIONAL NOTES
# MAGIC <details>
# MAGIC
# MAGIC ### Integration with Unity Catalog
# MAGIC
# MAGIC Unity Catalog provides the governance layer for your evaluation workflow, ensuring traceability, access control, and lineage tracking.
# MAGIC
# MAGIC **Agent registration**: When you register agents in Unity Catalog:
# MAGIC - All agent dependencies (vector indexes, UC functions, model endpoints) are tracked
# MAGIC - Access controls determine who can evaluate or modify agents
# MAGIC - Lineage shows which evaluation datasets and metrics produced each version
# MAGIC - Aliases (like `@champion`) enable clean promotion workflows
# MAGIC
# MAGIC ### Dataset and Trace Storage
# MAGIC
# MAGIC **Evaluation dataset storage**: Store datasets as Delta tables or volumes:
# MAGIC - Version datasets alongside agent versions
# MAGIC - Apply access controls to sensitive evaluation data
# MAGIC - Enable SQL-based dataset analysis and augmentation
# MAGIC - Support collaborative dataset curation
# MAGIC
# MAGIC **Trace storage**: MLflow traces are stored in Unity Catalog:
# MAGIC - Query traces using SQL for analysis
# MAGIC - Join traces with evaluation results for deeper insights
# MAGIC - Apply data governance policies to production trace data
# MAGIC - Enable cross-team trace sharing (where appropriate)
# MAGIC
# MAGIC This integration ensures your evaluation infrastructure benefits from the same governance, security, and collaboration capabilities as the rest of your data platform.
# MAGIC
# MAGIC ### MLflow Experiments and Runs
# MAGIC
# MAGIC MLflow Experiments organize your evaluation results, enabling comparison and analysis across agent iterations.
# MAGIC
# MAGIC **Experiment structure:**
# MAGIC
# MAGIC Each evaluation call to `mlflow.genai.evaluate()` creates a run within an experiment:
# MAGIC - **Runs** represent individual evaluation executions with specific configurations
# MAGIC - **Experiments** group related evaluation runs for comparison
# MAGIC - **Metrics** are logged at the run level (aggregated scores)
# MAGIC - **Artifacts** include detailed per-example results and evaluation datasets
# MAGIC
# MAGIC ### Comparison and Best Practices
# MAGIC
# MAGIC **Comparison capabilities:**
# MAGIC
# MAGIC MLflow UI enables systematic comparison:
# MAGIC - Compare metrics across runs to quantify improvements
# MAGIC - Visualize metric trends over time
# MAGIC - Filter runs by tags, parameters, or metrics
# MAGIC - Export results for external analysis
# MAGIC
# MAGIC **Best practices:**
# MAGIC
# MAGIC - Use consistent experiment naming conventions
# MAGIC - Tag runs with meaningful metadata (agent version, configuration, dataset version)
# MAGIC - Log hyperparameters and configuration as run parameters
# MAGIC - Add descriptive notes documenting run context and findings
# MAGIC </details>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### F1. Feedback Objects and Rationales
# MAGIC
# MAGIC <table style="width: 100%; border-collapse: collapse; table-layout: fixed;">
# MAGIC   <colgroup>
# MAGIC     <col style="width: 60%;">
# MAGIC     <col style="width: 40%;">
# MAGIC   </colgroup>
# MAGIC   <tr>
# MAGIC     <td style="vertical-align: top; padding-right: 20px;">
# MAGIC       <div class="code-block-dark" data-language="python">
# MAGIC Feedback(
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;value="yes",&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#35; Binary pass/fail or numerical score
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;rationale="The response correctly identifies the capital as Sacramento..."&nbsp;&nbsp;&#35; Explanation
# MAGIC &nbsp;&nbsp;&nbsp;&nbsp;metadata={...}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&#35; Additional structured information
# MAGIC )
# MAGIC       </div>
# MAGIC     </td>
# MAGIC     <td style="vertical-align: top; padding-left: 20px; font-size: 16px;">
# MAGIC       <p>MLflow judges return structured <code>Feedback</code> objects rather than simple scalar scores. This structure provides interpretability critical for understanding evaluation results.</p>
# MAGIC       <p><strong>Key components:</strong></p>
# MAGIC       <ul>
# MAGIC         <li><code>value</code>: The actual score or judgment</li>
# MAGIC         <li><code>rationale</code>: Human-readable explanation</li>
# MAGIC         <li><code>metadata</code>: Additional context</li>
# MAGIC       </ul>
# MAGIC     </td>
# MAGIC   </tr>
# MAGIC </table>
# MAGIC
# MAGIC <style id="prism-inline-css">
# MAGIC /* Prism Tomorrow Night theme - inlined */
# MAGIC code[class*="language-"],pre[class*="language-"]{color:#ccc;background:0 0;font-family:Consolas,Monaco,'Andale Mono','Ubuntu Mono',monospace;font-size:1em;text-align:left;white-space:pre;word-spacing:normal;word-break:normal;word-wrap:normal;line-height:1.5;tab-size:4;hyphens:none}pre[class*="language-"]{padding:1em;margin:.5em 0;overflow:auto}:not(pre)>code[class*="language-"],pre[class*="language-"]{background:#2d2d2d}:not(pre)>code[class*="language-"]{padding:.1em;border-radius:.3em;white-space:normal}.token.comment,.token.block-comment,.token.prolog,.token.doctype,.token.cdata{color:#999}.token.punctuation{color:#ccc}.token.tag,.token.attr-name,.token.namespace,.token.deleted{color:#e2777a}.token.function-name{color:#6196cc}.token.boolean,.token.number,.token.function{color:#f08d49}.token.property,.token.class-name,.token.constant,.token.symbol{color:#f8c555}.token.selector,.token.important,.token.atrule,.token.keyword,.token.builtin{color:#cc99cd}.token.string,.token.char,.token.attr-value,.token.regex,.token.variable{color:#7ec699}.token.operator,.token.entity,.token.url{color:#67cdcc}.token.important,.token.bold{font-weight:700}.token.italic{font-style:italic}.token.entity{cursor:help}.token.inserted{color:green}
# MAGIC </style>
# MAGIC
# MAGIC <script>
# MAGIC // Minimal Prism core + Python/SQL - inlined (no external requests)
# MAGIC (function(){
# MAGIC function escapeHtml(text) {
# MAGIC     var div = document.createElement('div');
# MAGIC     div.textContent = text;
# MAGIC     return div.innerHTML;
# MAGIC }
# MAGIC
# MAGIC var Prism = window.Prism = {
# MAGIC     languages: {},
# MAGIC     highlight: function(text, grammar) {
# MAGIC         return this.tokenize(text, grammar).map(function(token) {
# MAGIC             if (typeof token === 'string') return escapeHtml(token);
# MAGIC             var type = token.type, content = token.content;
# MAGIC             return '<span class="token ' + type + '">' + escapeHtml(content) + '</span>';
# MAGIC         }).join('');
# MAGIC     },
# MAGIC     tokenize: function(text, grammar) {
# MAGIC         var tokens = [text];
# MAGIC         for (var key in grammar) {
# MAGIC             var pattern = grammar[key];
# MAGIC             for (var i = 0; i < tokens.length; i++) {
# MAGIC                 if (typeof tokens[i] !== 'string') continue;
# MAGIC                 var match, matches = [];
# MAGIC                 pattern.lastIndex = 0;
# MAGIC                 while ((match = pattern.exec(tokens[i])) !== null) {
# MAGIC                     matches.push({index: match.index, length: match[0].length, value: match[0]});
# MAGIC                 }
# MAGIC                 if (!matches.length) continue;
# MAGIC                 var newTokens = [];
# MAGIC                 var lastIndex = 0;
# MAGIC                 matches.forEach(function(m) {
# MAGIC                     if (m.index > lastIndex) newTokens.push(tokens[i].substring(lastIndex, m.index));
# MAGIC                     newTokens.push({type: key, content: m.value});
# MAGIC                     lastIndex = m.index + m.length;
# MAGIC                 });
# MAGIC                 if (lastIndex < tokens[i].length) newTokens.push(tokens[i].substring(lastIndex));
# MAGIC                 tokens.splice.apply(tokens, [i, 1].concat(newTokens));
# MAGIC             }
# MAGIC         }
# MAGIC         return tokens;
# MAGIC     },
# MAGIC     highlightElement: function(element) {
# MAGIC         var code = element.textContent;
# MAGIC         var lang = element.className.match(/language-(\w+)/);
# MAGIC         lang = lang ? lang[1] : 'python';
# MAGIC         var grammar = this.languages[lang] || this.languages.python;
# MAGIC         element.innerHTML = this.highlight(code, grammar);
# MAGIC     }
# MAGIC };
# MAGIC
# MAGIC // Python grammar
# MAGIC Prism.languages.python = {
# MAGIC     'comment': /#.*/g,
# MAGIC     'string': /("""[\s\S]*?"""|'''[\s\S]*?'''|"[^"]*"|'[^']*')/g,
# MAGIC     'keyword': /\b(import|from|def|class|return|if|elif|else|for|while|try|except|finally|with|as|pass|break|continue|yield|lambda|async|await|None|True|False)\b/g,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[-+*/%=<>!&|^~]+/g,
# MAGIC     'punctuation': /[{}[\];(),.]/g
# MAGIC };
# MAGIC
# MAGIC // SQL grammar
# MAGIC Prism.languages.sql = {
# MAGIC     'comment': /--.*|\/\*[\s\S]*?\*\//g,
# MAGIC     'string': /'[^']*'/g,
# MAGIC     'keyword': /\b(SELECT|FROM|WHERE|INSERT|UPDATE|DELETE|CREATE|ALTER|DROP|GRANT|TABLE|CATALOG|TO|ON|LIMIT|AND|OR|NOT|IN|AS|IS|NULL|JOIN|LEFT|RIGHT|INNER|OUTER|GROUP|BY|ORDER|HAVING|DISTINCT|COUNT|SUM|AVG|MAX|MIN)\b/gi,
# MAGIC     'function': /\b\w+(?=\()/g,
# MAGIC     'number': /\b\d+\.?\d*\b/g,
# MAGIC     'operator': /[<>!=]=?|[-+*/%]|\b(LIKE|BETWEEN)\b/gi,
# MAGIC     'punctuation': /[;,.()]/g
# MAGIC };
# MAGIC
# MAGIC // Auto-process code blocks
# MAGIC document.querySelectorAll('.code-block-dark').forEach(function(block) {
# MAGIC     if (block.getAttribute('data-processed')) return;
# MAGIC     block.setAttribute('data-processed', 'true');
# MAGIC     var lang = block.getAttribute('data-language') || 'python';
# MAGIC     var code = block.textContent.trim();
# MAGIC     var id = 'code-dark-' + Math.random().toString(36).substr(2, 9);
# MAGIC     block.innerHTML = 
# MAGIC         '<div style="position:relative;margin:16px 0;max-width:100%;">' +
# MAGIC             '<button class="copy-btn" style="position:absolute;top:8px;right:8px;padding:4px 12px;font-size:12px;background:#555;color:#fff;border:1px solid #666;border-radius:4px;cursor:pointer;z-index:10;">Copy</button>' +
# MAGIC             '<pre style="background:#2d2d2d;border-radius:8px;padding:16px;padding-top:40px;overflow-x:auto;margin:0;border:1px solid #444;max-width:100%;box-sizing:border-box;white-space:pre;"><code id="' + id + '" class="language-' + lang + '" style="font-family:Consolas,Monaco,monospace;font-size:13px;"></code></pre>' +
# MAGIC         '</div>';
# MAGIC     var codeEl = document.getElementById(id);
# MAGIC     codeEl.textContent = code;
# MAGIC     Prism.highlightElement(codeEl);
# MAGIC     block.querySelector('.copy-btn').onclick = function() {
# MAGIC         var t = document.createElement('textarea');
# MAGIC         t.value = code;
# MAGIC         document.body.appendChild(t);
# MAGIC         t.select();
# MAGIC         document.execCommand('copy');
# MAGIC         document.body.removeChild(t);
# MAGIC         this.textContent = '✓ Copied!';
# MAGIC         var btn = this;
# MAGIC         setTimeout(function() { btn.textContent = 'Copy'; }, 2000);
# MAGIC     };
# MAGIC });
# MAGIC })();
# MAGIC </script>

# COMMAND ----------

# MAGIC %md
# MAGIC ### F2. Why Rationales Matter
# MAGIC
# MAGIC - **Debugging**: Understand why an example failed, not just that it failed
# MAGIC - **Judge validation**: Verify that judges are reasoning correctly
# MAGIC - **Pattern identification**: Common rationale themes reveal systemic issues
# MAGIC - **Stakeholder communication**: Explain evaluation results to non-technical audiences
# MAGIC
# MAGIC **Using rationales effectively:**
# MAGIC
# MAGIC 1. Read rationales for all failures to identify patterns
# MAGIC 2. Spot-check rationales for passes to ensure judge is reasoning correctly
# MAGIC 3. Extract common rationale phrases to categorize failure types
# MAGIC 4. Share representative rationales when discussing evaluation with teams
# MAGIC
# MAGIC The combination of pass/fail scores with detailed rationales makes MLflow evaluation both quantitative (trackable metrics) and qualitative (understandable reasoning).

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ## ⚠️ Lab Checkpoint
# MAGIC <div style="border-left: 4px solid #ff9800; background: #fff3e0; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC   <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC     <span style="font-size: 24px;"></span>
# MAGIC     <div>
# MAGIC       <strong style="color: #e65100; font-size: 1.1em;">Lab Checkpoint</strong>
# MAGIC       <p style="margin: 8px 0 0 0; color: #333;">Navigate to <strong>06 Lab - Developer and SME Feedback with MLflow</strong> to explore human feedback capabilities and complete your evaluation learning journey. When you are finished, navigate back to this lecture notebook for the conclusion.</p>
# MAGIC     </div>
# MAGIC   </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ## G. Practical Application - What to Consider
# MAGIC As you work through the demonstrations, consider how these concepts apply to your own use cases:
# MAGIC
# MAGIC **Questions to guide your thinking:**
# MAGIC - What quality dimensions matter most for your application?
# MAGIC - Which failure modes would be most problematic in production?
# MAGIC - How will you curate evaluation datasets that reflect real usage?
# MAGIC - What existing systems or processes could inform your evaluation criteria?
# MAGIC - How will you integrate evaluation into your development workflow?
# MAGIC - What metrics will you track in production monitoring?
# MAGIC
# MAGIC Effective evaluation is deeply context-dependent. While MLflow provides powerful tools, you must define what "good" means for your specific application, users, and business requirements.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conclusion
# MAGIC
# MAGIC You now have the conceptual foundation to implement systematic agent evaluation. The upcoming demonstrations will transform these concepts into practical skills, showing you exactly how to evaluate real agents, interpret results, and drive quality improvements.
# MAGIC
# MAGIC Remember that evaluation is not a one-time activity but an ongoing discipline. As your agents evolve, as usage patterns shift, and as your understanding deepens, your evaluation approach should evolve too. MLflow's flexible framework supports this continuous improvement while maintaining rigor and reproducibility.
# MAGIC
# MAGIC The quality of your AI agents ultimately depends on the quality of your evaluation. Invest in building robust evaluation infrastructure early, and you'll reap benefits throughout your agent's lifecycle—from development through production and beyond.

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>