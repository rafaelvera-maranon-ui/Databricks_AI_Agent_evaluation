# Databricks notebook source
# MAGIC %md
# MAGIC <div style="text-align: center; line-height: 0; padding-top: 9px;">
# MAGIC <img src="https://databricks.com/wp-content/uploads/2018/03/db-academy-rgb-1200px.png" alt="Databricks Learning">
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC # Demo - Agent Setup
# MAGIC ## Overview
# MAGIC
# MAGIC This demo focuses on the setup of a custom agent using environment variables specific to the user and Python code located in the folder `./artifacts`. At this point in the lifecycle of your agent application, you are ready for evaluation and this notebook acts a checkpoint where you have an agent already registered to Unity Catalog.
# MAGIC
# MAGIC ## Learning Objectives
# MAGIC
# MAGIC By the end of this demo, you will be able to:
# MAGIC
# MAGIC - Understand the initial setup of your agent and Databricks environment that will be used with other demos and labs within this course.

# COMMAND ----------

# MAGIC %md
# MAGIC ## A. Environment Setup and Prerequisites
# MAGIC
# MAGIC This section covers the essential setup steps required before configuring your agent. We'll establish compute requirements, install dependencies, configure dataset access, and create all necessary classroom assets.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A1. Compute Requirements
# MAGIC
# MAGIC This course has been configured to run on Serverless compute. While classic compute may also work, testing has been performed on serverless.
# MAGIC
# MAGIC **This demo was tested using version 4 of Serverless compute.** To ensure that you are using the correct version of Serverless, please [see this documentation on viewing and changing your notebook's Serverless version](https://docs.databricks.com/aws/en/compute/serverless/dependencies).
# MAGIC
# MAGIC <div style="border-left: 4px solid #f44336; background: #ffebee; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #c62828; font-size: 1.1em;">Required - Select Serverless Compute</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">You must attach this notebook to a Serverless compute resource before proceeding.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md
# MAGIC ### A2. Install Dependencies
# MAGIC
# MAGIC As part of the workspace setup, several Python libraries will need to be installed by running the following setup script. This includes MLflow with Databricks integration and other required packages for evaluation.

# COMMAND ----------

# MAGIC %run ./Includes/Classroom-Setup-1

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A3. Configured Catalog and Schema
# MAGIC
# MAGIC This notebook uses a pre-defined Unity Catalog catalog and schema when referencing Unity Catalog assets. These values are stored in the variables `catalog_name` and `schema_name`.
# MAGIC
# MAGIC While you may optionally create or use your own catalog, the schema is intentionally constrained to ensure consistent object naming and predictable behavior throughout the notebook.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Non-Vocareum Users</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">
# MAGIC Your catalog name will appear in the form <code>labuser_username</code>. For example, if your username is
# MAGIC <code>spark.mcsparky@databricks.com</code>, your catalog name will be <code>labuser_spark_mcsparky</code>.
# MAGIC </p>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">
# MAGIC Non-Vocareum users may also create or use a custom catalog by passing a catalog name into <code>DemoSetup()</code>.
# MAGIC You may optionally specify a custom Delta Share name as well.
# MAGIC </p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Vocareum Users</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">
# MAGIC If you are using <strong>Vocareum</strong>, your catalog has already been configured for you and follows the
# MAGIC format <code>labuserXXX_XXX</code>, which corresponds to your Vocareum username.
# MAGIC </p>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">
# MAGIC Vocareum users <strong>do not</strong> need to modify <code>DemoSetup()</code>.
# MAGIC </p>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">
# MAGIC <em>Example catalog name in Vocareum:</em> <code> "labuser31415926_5358979323"</code>
# MAGIC </p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A4. Configure Airbnb Dataset Access
# MAGIC
# MAGIC This demonstration relies on the Airbnb dataset from Databricks Marketplace. You may already have access to the Airbnb dataset.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Non-Vocareum Users: Check Access</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Check in the <strong>Catalog Explorer</strong> by searching for <code>databricks_airbnb_sample_data</code>. Note this is the default value for users <strong>outside Vocareum</strong>.</p>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">If you don't have access or can't see the dataset in your <strong>Catalog Explorer</strong>, follow these steps:</p>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">1. Navigate to Marketplace and search <strong>Airbnb Sample Data</strong> and click on the tile that reads <strong>Airbnb Sample Data</strong>.</p>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">2. Next, click <strong>Get instant access</strong> and follow the on-screen instructions to bring that dataset in.</p>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">3. Create a unique Databricks share name. If a name is already in use, you will need to use a different name. Copy the same name into the cell below. For example: <code>databricks_share_name = "unique_name"</code>.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Vocareum Users: Default Access</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">If you launched this demo <strong>in a Vocareum environment</strong>, you will automatically have access to the Delta share called <code>dbacademy_airbnb_sample_data</code>.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

# databricks_share_name = "<unique_name>" # Default value is databricks_airbnb_sample_data

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### A5. Create Classroom Assets
# MAGIC
# MAGIC We are now ready to provision all assets required for this follow-along demo. Running the next cell will automatically create and configure the following resources across Unity Catalog, MLflow, and Databricks Agent deployment.
# MAGIC
# MAGIC | Artifact Type                | Name / Pattern                                                                 | Description                                                                                                                  |
# MAGIC |-----------------------------|----------------------------------------------------------------------------------|------------------------------------------------------------------------------------------------------------------------------|
# MAGIC | Catalog                     | `labuser_username` or `labuser_XXXX`                                              | Unity Catalog used for all demo assets (resolved dynamically per user and set as the active catalog).                        |
# MAGIC | Schema                      | `demo_agent_eval`                                                                | Schema created if it does not already exist and set as the active schema for all demo objects.                               |
# MAGIC | Volume                      | `agent_vol`                                                                     | Unity Catalog volume used to store agent configuration files and evaluation datasets.                                        |
# MAGIC | Delta Table                 | `sf_airbnb_listings`                                                            | Delta table created from the Airbnb CSV with a derived text field (`listing_source_information`) for GenAI use.              |
# MAGIC | UC SQL Function             | `avg_neigh_price`                                                               | Returns the average Airbnb listing price for a given San Francisco neighborhood.                                             |
# MAGIC | UC SQL Function             | `cnt_by_room_type`                                                              | Counts Airbnb listings by room type within a specified neighborhood.                                                          |
# MAGIC | UC SQL Function             | `calculate_fare_estimate`                                                       | Calculates an estimated fare based on trip distance and base fare (NYC Taxi agent).                                          |
# MAGIC | UC SQL Function             | `get_trip_info`                                                                 | Returns trip statistics (count, avg/min/max/median fare, distance) for trips between pickup and dropoff zip codes (NYC Taxi agent). |
# MAGIC | MLflow Experiment           | `airbnb_experiment`                                                          | MLflow experiment used for Airbnb agent registration, evaluation, and logging.                                               |
# MAGIC | MLflow Experiment           |                                                        |
# MAGIC | MLflow Experiment           | `nyc_taxi_experiment`                                                           | MLflow experiment used for NYC Taxi agent registration and evaluation.                                                        |
# MAGIC | YAML Configuration File     | `./artifacts/configs/airbnb_agent_config.yaml`                                         | Core agent configuration for the Airbnb agent (system prompt, catalog/schema context, LLM endpoint).                         |
# MAGIC | YAML Configuration File     | `./artifacts/configs/nyc_taxi_agent_config.yaml`                                | Core agent configuration for the NYC Taxi agent (system prompt, catalog/schema context, LLM endpoint).                       |
# MAGIC | YAML Configuration File     | `./artifacts/configs/agent_eval_config.yaml`                                    | Evaluation configuration defining correctness, tool-usage, and custom evaluation prompts and endpoints.                    |
# MAGIC | Evaluation Dataset (JSON)   | `agent_vol/*.json`                                                              | Predefined evaluation datasets (correctness, guidelines, custom, row-level, and NYC taxi evals) written directly to the UC volume.   |
# MAGIC | MLflow Model                | `airbnb_eval_agent`                                                                    | Tool-calling agent (Airbnb) logged with MLflow and registered into Unity Catalog Model Registry. This agent is also deployed with the name `labuser<XXX>_agent`. |
# MAGIC | MLflow Model                | `nyc_taxi_eval_agent`                                                           | Tool-calling agent (NYC Taxi) logged with MLflow and registered into Unity Catalog Model Registry (not deployed).            |
# MAGIC | Model Alias                 | `champion`                                                                      | Alias automatically assigned to newly registered model versions for both agents.                                             |
# MAGIC | Model Resources             | LLM endpoint, UC SQL functions                                                   | Models registered with explicit dependencies on the serving endpoint and Unity Catalog SQL functions.                        |
# MAGIC | Agent Deployment            | Auto-generated serving endpoint                                                  | Airbnb agent deployed using the Databricks Agents SDK with scale-to-zero enabled. NYC Taxi agent is registered but not deployed. |
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">Note</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">Vector Search can certainly be integrated into your agent application, but is not done so due to time constraints in this course.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

demo_setup = DemoSetup(
    # catalog_name = <FILL_IN> # Pass only if you want to create a new catalog
    # databricks_share_name # Pass only if you created a new share during the setup above
)
demo_setup.run()

# COMMAND ----------

# MAGIC %md
# MAGIC ## B. Import The Agent and View MLflow Trace
# MAGIC
# MAGIC In this section, we'll import and test our agent that's been instrumented with MLflow tracing. The agent combines SQL functions to provide comprehensive responses about San Francisco Airbnb listings.
# MAGIC
# MAGIC MLflow tracing automatically captures the execution flow of our agent, including retrieval operations, function calls, and LLM interactions.

# COMMAND ----------

# MAGIC %md-sandbox
# MAGIC ### B1. Import the Agent
# MAGIC
# MAGIC Here we will load the model using the Unity Catalog path and alias that was created as a part of the setup script for this demo using `demo_setup.load_agent()`.
# MAGIC
# MAGIC <div style="border-left: 4px solid #1976d2; background: #e3f2fd; padding: 16px 20px; border-radius: 4px; margin: 16px 0;">
# MAGIC <div style="display: flex; align-items: flex-start; gap: 12px;">
# MAGIC <div>
# MAGIC <strong style="color: #0d47a1; font-size: 1.1em;">We Are Using A Simple Agent</strong>
# MAGIC <p style="margin: 8px 0 0 0; color: #333;">The custom agent built in this demo and used in other demos/labs is really a <strong>tool-calling agent</strong> using UDFs registered to Unity Catalog. Your agent may have a varienty tools, but this is not the focus of our current objective, which is to understand the basics of evaluation.</p>
# MAGIC </div>
# MAGIC </div>
# MAGIC </div>

# COMMAND ----------

agent = demo_setup.load_agent("airbnb_eval_agent")

# COMMAND ----------

# MAGIC %md
# MAGIC ### B2. Sample Questions
# MAGIC
# MAGIC Now that we have our agent working, let's pass some questions using the `predict()` method defined in `airbnb_agent.py`. Let's first create a helper function we can use to send the expected payload to the agent.

# COMMAND ----------

def agent_payload(question: str):
    return [{"input": [{"role": "user", "content": question}]}]

# COMMAND ----------

agent.predict(agent_payload("What tools do you have available?"))

# COMMAND ----------

# MAGIC %md
# MAGIC ### B3. Inspect the Trace
# MAGIC
# MAGIC Based on the output above, we can see the tools the agent has access to. Let's next ask a question that will invoke a couple tool calls. Namely, the next question will nudge the agent to use both:
# MAGIC
# MAGIC 1. `avg_neigh_price`
# MAGIC 2. `cnt_by_room_type`
# MAGIC
# MAGIC The screenshot below is an example of the output when running the next cell and what you should expect. Notice the tools defined above are being called.
# MAGIC
# MAGIC ![mlflow-toolcall.png](./Includes/images/built-in agents with mlflow/mlflow-toolcall.png "mlflow-toolcall.png")

# COMMAND ----------

agent.predict(agent_payload("Can you tell me what the average price is in Mission? Also, what's the number of listings for that neighborhood that have private rooms?"))

# COMMAND ----------

# MAGIC %md
# MAGIC ## C. Inspect the Trace in Unity Catalog
# MAGIC
# MAGIC Navigate to the **Catalog Explorer** and search for **airbnb_eval_agent**. There you will find a model (at least **Version 1**) with the alias **@champion**. Click on it and navigate to the **Traces** tab. There you will find the same two requests we sent above.

# COMMAND ----------

# MAGIC %md
# MAGIC ## Conclusion
# MAGIC
# MAGIC - Your agent is now registered in Unity Catalog and can be loaded using `mlflow.pyfunc.load_model()`
# MAGIC - MLflow tracing automatically captures all agent interactions, providing valuable data for evaluation
# MAGIC - The agent successfully combines multiple tools (SQL functions) to provide comprehensive responses
# MAGIC - All traces are accessible through the Unity Catalog interface for monitoring and debugging
# MAGIC
# MAGIC ### Next Steps
# MAGIC
# MAGIC With your agent now properly configured and registered, you're ready to move on to the next notebooks in this series where you'll learn how to evaluate agent performance, create evaluation datasets from traces, and implement comprehensive testing strategies.
# MAGIC
# MAGIC Remember that in future notebooks, you'll load your agent directly using `mlflow.pyfunc.load_model()` rather than the `demo_setup()` helper function used in this demo.

# COMMAND ----------

# MAGIC %md
# MAGIC &copy; 2026 Databricks, Inc. All rights reserved. Apache, Apache Spark, Spark, the Spark Logo, Apache Iceberg, Iceberg, and the Apache Iceberg logo are trademarks of the <a href="https://www.apache.org/" target="_blank">Apache Software Foundation</a>.<br/><br/><a href="https://databricks.com/privacy-policy" target="_blank">Privacy Policy</a> | <a href="https://databricks.com/terms-of-use" target="_blank">Terms of Use</a> | <a href="https://help.databricks.com/" target="_blank">Support</a>